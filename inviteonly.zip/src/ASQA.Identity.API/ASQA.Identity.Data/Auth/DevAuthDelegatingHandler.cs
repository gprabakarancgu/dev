﻿using ASQA.Identity.Data.Model;
using Azure.Identity;
using Microsoft.Extensions.Options;

namespace ASQA.Identity.Data.Auth;

public class DevAuthDelegatingHandler : DelegatingHandler
{
    private DataverseOptions options;

    public DevAuthDelegatingHandler(IOptions<DataverseOptions> options)
    {
        this.options = options.Value;
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var credentials = new DefaultAzureCredential();
        var accessToken = await credentials.GetTokenAsync(new Azure.Core.TokenRequestContext([$"{options.Scope}/.default"]));
        if (accessToken.Token != null)
        {
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken.Token);
        }
        var response = await base.SendAsync(request, cancellationToken);
        return response;
    }
}