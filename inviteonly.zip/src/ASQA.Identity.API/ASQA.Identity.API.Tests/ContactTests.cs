using ASQA.Identity.API.Models.Identity.Contact;

namespace ASQA.Identity.API.Tests
{
    public class ContactTests
    {
        [Theory]
        [InlineData("test@test.com", null, null, null, "test@test.com", null, null)]
        [InlineData("test@test.com", "test@test.com", null, null, "test@test.com", null, null)]
        [InlineData("test@test.com", "test1@test.com", null, null, "test@test.com", "test1@test.com", null)]
        [InlineData("test@test.com", "test1@test.com", "test2@test.com", null, "test@test.com", "test1@test.com", "test2@test.com")]
        [InlineData("test@test.com", "test1@test.com", "test2@test.com", "test3@test.com", "test@test.com", "test1@test.com", "test2@test.com")]
        [InlineData("test@test.com", null, "test2@test.com", null, "test@test.com", "test2@test.com", null)]
        [InlineData("test@test.com", null, null, "test3@test.com", "test@test.com", null, "test3@test.com")]
        [InlineData("test@test.com", null, "test2@test.com", "test3@test.com", "test@test.com", "test2@test.com", "test3@test.com")]
        [InlineData("test@test.com", "test1@test.com", null, "test2@test.com", "test@test.com", "test1@test.com", "test2@test.com")]
        [InlineData("test@test.com", "test1@test.com", "test1@test.com", "test1@test.com", "test@test.com", "test1@test.com", "test1@test.com")]
        public void SetEmail_ShouldShiftEmails(string newEmail, string email1, string email2, string email3, string expectedEmail1, string expectedEmail2, string expectedEmail3)
        {
            // Arrange
            var contact = new Contact { Email = email1, Email2 = email2, Email3 = email3 };

            // Act
            contact.SetEmail(newEmail);

            // Assert
            Assert.Equal(contact.Email, expectedEmail1);
            Assert.Equal(contact.Email2, expectedEmail2);
            Assert.Equal(contact.Email3, expectedEmail3);
        }

        [Theory]
        [InlineData("0488888888", null, null, null, "0488888888", null, null)]
        [InlineData("0488888888", "0488888888", null, null, "0488888888", null, null)]
        [InlineData("0488888888", "0411111111", null, null, "0488888888", "0411111111", null)]
        [InlineData("0488888888", "0411111111", "0422222222", null, "0488888888", "0411111111", "0422222222")]
        [InlineData("0488888888", "0411111111", "0422222222", "0433333333", "0488888888", "0411111111", "0422222222")]
        [InlineData("0488888888", null, "0422222222", null, "0488888888", "0422222222", null)]
        [InlineData("0488888888", null, null, "0433333333", "0488888888", null, "0433333333")]
        [InlineData("0488888888", null, "0422222222", "0433333333", "0488888888", "0422222222", "0433333333")]
        [InlineData("0488888888", "0411111111", null, "0422222222", "0488888888", "0411111111", "0422222222")]
        [InlineData("0488888888", "0411111111", "0411111111", "0411111111", "0488888888", "0411111111", "0411111111")]
        public void SetMobile_ShouldShiftMobileNumbers(string newMobile, string mobile1, string mobile2, string mobile3, string expectedMobile1, string expectedMobile2, string expectedMobile3)
        {
            // Arrange
            var contact = new Contact { Mobile = mobile1, Mobile2= mobile2, Mobile3 = mobile3 };

            // Act
            contact.SetMobile(newMobile);

            // Assert
            Assert.Equal(contact.Mobile, expectedMobile1);
            Assert.Equal(contact.Mobile2, expectedMobile2);
            Assert.Equal(contact.Mobile3, expectedMobile3);
        }
    }
}