using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;

namespace ASQA.Identity.API;

public class ConfigureJwtBearerOptions(IConfiguration configuration, IHttpClientFactory httpClientFactory)
    : IConfigureNamedOptions<JwtBearerOptions>
{
    private readonly HttpClient httpClient = httpClientFactory.CreateClient("jwt");

    public void Configure(JwtBearerOptions options)
    {
        options.UseSecurityTokenValidators = true;
        options.IncludeErrorDetails = true;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidIssuer = $"https://sts.windows.net/{configuration["AzureAd:TenantId"]}/",
            ValidateIssuer = true,
            ValidAudience = configuration["AzureAd:Audience"],
            ValidateAudience = true,
            ValidateIssuerSigningKey = true,
            ValidateLifetime = true
        };
        var configManager = new ConfigurationManager<OpenIdConnectConfiguration>(
            $"https://login.microsoftonline.com/{configuration["AzureAd:TenantId"]}/.well-known/openid-configuration",
            new OpenIdConnectConfigurationRetriever(),
            new HttpDocumentRetriever(httpClient) { RequireHttps = true });

        options.ConfigurationManager = configManager;
    }

    public void Configure(string? name, JwtBearerOptions options)
    {
        Configure(options);
    }
}