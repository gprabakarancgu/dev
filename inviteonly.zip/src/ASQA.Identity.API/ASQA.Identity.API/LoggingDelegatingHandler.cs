﻿namespace ASQA.Identity.API
{
    public class LoggingDelegatingHandler(ILogger<LoggingDelegatingHandler> logger) : DelegatingHandler
    {
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            try
            {
                var response = await base.SendAsync(request, cancellationToken);
                return response;
            }
            catch (Exception e)
            {
                logger.LogError(e, "Failed to connect");
                throw;
            }
           
        }
    }
}
