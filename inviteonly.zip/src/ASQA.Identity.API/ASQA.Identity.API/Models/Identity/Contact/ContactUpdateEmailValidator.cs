﻿using FluentValidation;

namespace ASQA.Identity.API.Models.Identity.Contact;

public class ContactUpdateEmailValidator : AbstractValidator<ContactUpdateEmailRequest>
{
    public ContactUpdateEmailValidator()
    {
        RuleFor(request => request.Email)
            .Cascade(CascadeMode.Stop)
            .NotEmpty().WithMessage("Email is required")
            .EmailAddress();
        RuleFor(request => request.ContactId).NotEmpty().WithMessage("Contact ID is required");
    }
}