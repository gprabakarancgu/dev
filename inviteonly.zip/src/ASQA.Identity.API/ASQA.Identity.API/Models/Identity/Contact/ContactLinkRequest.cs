﻿namespace ASQA.Identity.API.Models.Identity.Contact
{
    public class ContactLinkRequest(string contactId, string objectId, string email)
    {
        public string ContactId { get; set; } = contactId;
        public string ObjectId { get; } = objectId;
        public string Email { get; set; } = email;
    }
}
