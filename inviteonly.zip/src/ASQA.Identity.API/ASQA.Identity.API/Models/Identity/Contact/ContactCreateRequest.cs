﻿namespace ASQA.Identity.API.Models.Identity.Contact;

public class ContactCreateRequest(string email, string firstName, string lastName)
{
    public string Email { get; set; } = email;
    public string FirstName { get; } = firstName;
    public string LastName { get; } = lastName;
}