﻿namespace ASQA.Identity.API.Models.Identity.Contact
{
    public class ContactVerificationRequest(string passcode, string arn)
    {
        public string? Passcode { get; } = passcode;
        public string Arn { get; set; } = arn;
    }
}
