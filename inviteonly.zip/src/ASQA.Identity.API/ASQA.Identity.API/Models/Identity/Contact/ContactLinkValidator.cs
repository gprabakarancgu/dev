﻿using FluentValidation;

namespace ASQA.Identity.API.Models.Identity.Contact
{
    public class ContactLinkValidator : AbstractValidator<ContactLinkRequest>
    {
        public ContactLinkValidator()
        {
            RuleFor(request => request.Email)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("Email is required")
                .EmailAddress();
            RuleFor(request => request.ContactId).NotEmpty().WithMessage("Contact ID is required");
            RuleFor(request => request.ObjectId).NotEmpty().WithMessage("Object ID is required");
        }
    }
}
