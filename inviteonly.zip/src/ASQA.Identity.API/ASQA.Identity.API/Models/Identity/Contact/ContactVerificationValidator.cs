﻿using FluentValidation;

namespace ASQA.Identity.API.Models.Identity.Contact
{
    public class ContactVerificationValidator : AbstractValidator<ContactVerificationRequest>
    {
        public ContactVerificationValidator()
        {
            RuleFor(request => request.Arn).NotEmpty().WithMessage("ARN is required");
            //RuleFor(request => request.Passcode).NotEmpty().WithMessage("Passcode is required");
        }
    }
}
