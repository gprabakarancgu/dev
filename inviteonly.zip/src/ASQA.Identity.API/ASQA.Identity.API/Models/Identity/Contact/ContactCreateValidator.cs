﻿using FluentValidation;

namespace ASQA.Identity.API.Models.Identity.Contact;

public class ContactCreateValidator : AbstractValidator<ContactCreateRequest>
{
    public ContactCreateValidator()
    {
        RuleFor(request => request.Email)
            .Cascade(CascadeMode.Stop)
            .NotEmpty().WithMessage("Email is required")
            .EmailAddress();
        RuleFor(request => request.FirstName).NotEmpty().WithMessage("First name is required");
        RuleFor(request => request.LastName).NotEmpty().WithMessage("Last name is required");
    }
}