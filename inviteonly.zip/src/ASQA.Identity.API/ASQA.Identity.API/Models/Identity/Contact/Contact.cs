﻿namespace ASQA.Identity.API.Models.Identity.Contact
{
    public class Contact
    {
        public string ContactId { get; set; }
        public string Email { get; set; }
        public string Email2 { get; set; }
        public string Email3 { get; set; }
        public string Mobile { get; set; }
        public string Mobile2 { get; set; }
        public string Mobile3 { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName { get; set; }
        public bool IsImpactedIndividual { get; set; }

        public void SetEmail(string newEmail)
        {
            if (string.IsNullOrEmpty(newEmail)) return;

            var emails = new[] { Email, Email2, Email3 };

            // Insert new email at the top, shift others down
            var updated = ShiftAndInsert(emails, newEmail);

            Email = updated[0];
            Email2 = updated[1];
            Email3 = updated[2];
        }

        public void SetMobile(string newMobile)
        {
            if (string.IsNullOrEmpty(newMobile)) return;

            var mobiles = new[] { Mobile, Mobile2, Mobile3 };

            // Insert new mobile at the top, shift others down
            var updated = ShiftAndInsert(mobiles, newMobile);

            Mobile = updated[0];
            Mobile2 = updated[1];
            Mobile3 = updated[2];
        }

        private string[] ShiftAndInsert(string[] values, string newValue)
        {
            var list = new List<string> { newValue // Add new value to the front
            };

            foreach (var val in values)
            {
                var valIndex = Array.IndexOf(values, val);
                if (!string.IsNullOrEmpty(val) && val != newValue)
                {
                    var nextValIndex = list.Count;
                    if (nextValIndex >= valIndex)
                    {
                        list.Add(val);
                    }
                    else
                    {
                        var diff = valIndex - nextValIndex;
                        for (var i = 0; i < diff; i++)
                        {
                            list.Add(null!);
                        }
                        list.Add(val);
                    }
                }
            }

            // Trim to max 3 values
            while (list.Count < 3) list.Add(null!);
            return list.Take(3).ToArray();
        }

    }
}
