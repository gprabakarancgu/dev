﻿using FluentValidation;

namespace ASQA.Identity.API.Models.Identity.ImpactedIndividual;

public class ImpactedIndividualLinkValidator : AbstractValidator<ImpactedIndividualLinkRequest>
{
    public ImpactedIndividualLinkValidator()
    {
        RuleFor(request => request.Email)
            .Cascade(CascadeMode.Stop)
            .NotEmpty().WithMessage("Email is required")
            .EmailAddress();
        RuleFor(request => request.ContactId).NotEmpty().WithMessage("Contact ID is required");
        RuleFor(request => request.ObjectId).NotEmpty().WithMessage("Object ID is required");
    }
}