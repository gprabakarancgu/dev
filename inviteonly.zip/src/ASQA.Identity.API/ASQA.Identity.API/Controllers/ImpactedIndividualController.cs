﻿using ASQA.Identity.API.Models;
using ASQA.Identity.API.Models.Identity.ImpactedIndividual;
using ASQA.Identity.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ASQA.Identity.API.Controllers
{
    [Authorize]
    [Route("identity/impacted-individual")]
    public class ImpactedIndividualController(
        ILogger<ImpactedIndividualController> logger,
        IImpactedIndividualService impactedIndividualService,
        IContactService contactService)
        : Controller
    {
        [HttpPost]
        [Route("verify")]
        public async Task<IActionResult> Verify([FromBody] ImpactedIndividualVerificationRequest request)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage));
                logger.LogError("Invalid request. {message}", message);
                return BadRequest(new ErrorModel("Invalid requests."));
            }

            var response = await impactedIndividualService.Verify(request);

            if (response?.Error != null)
            {
                return BadRequest(response.Error);
            }

            if (response?.Data == null)
            {
                return BadRequest(new ErrorModel("User not found"));
            }

            return Ok(response.Data);
        }

        [HttpPost]
        [Route("link")]
        public async Task<IActionResult> Link([FromBody] ImpactedIndividualLinkRequest request)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage));
                logger.LogError("Invalid request. {message}", message);
                return BadRequest(new ErrorModel("Invalid requests."));
            }

            var response = await impactedIndividualService.Link(request);

            if (response?.Error != null)
            {
                return BadRequest(response.Error);
            }

            if (response?.Data == null)
            {
                return BadRequest(new ErrorModel("User not found"));
            }

            return Ok(response.Data);
        }
    }
}
