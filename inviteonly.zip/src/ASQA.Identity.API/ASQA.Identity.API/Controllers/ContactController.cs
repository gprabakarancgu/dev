﻿using ASQA.Identity.API.Models;
using ASQA.Identity.API.Models.Identity.Contact;
using ASQA.Identity.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ASQA.Identity.API.Controllers
{
    [Authorize]
    [Route("identity/contact")]
    public class ContactController(
        ILogger<ContactController> logger,
        IContactService contactService)
        : Controller
    {
        [HttpPost]
        [Route("verify")]
        public async Task<IActionResult> Verify([FromBody] ContactVerificationRequest request)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage));
                logger.LogError("Invalid request. {message}", message);
                return BadRequest(new ErrorModel("Invalid requests."));
            }

            var response = await contactService.Verify(request);

            if (response?.Error != null)
            {
                return BadRequest(response.Error);
            }

            if (response?.Data == null)
            {
                return BadRequest(new ErrorModel("User not found"));
            }

            return Ok(response.Data);
        }

        [HttpPost]
        [Route("link")]
        public async Task<IActionResult> Link([FromBody] ContactLinkRequest request)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage));
                logger.LogError("Invalid request. {message}", message);
                return BadRequest(new ErrorModel("Invalid requests."));
            }

            var response = await contactService.Link(request);

            if (response?.Error != null)
            {
                return BadRequest(response.Error);
            }

            if (response?.Data == null)
            {
                return BadRequest(new ErrorModel("User not found"));
            }

            return Ok(response.Data);
        }
        [HttpPost]
        [Route("update-email")]
        public async Task<IActionResult> UpdateEmail([FromBody] ContactUpdateEmailRequest request)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage));
                logger.LogError("Invalid request. {message}", message);
                return BadRequest(new ErrorModel("Invalid requests."));
            }

            var response = await contactService.UpdateEmail(request);

            if (response?.Error != null)
            {
                return BadRequest(response.Error);
            }

            if (response?.Data == null)
            {
                return BadRequest(new ErrorModel("User not found"));
            }

            return Ok(response.Data);
        }

        [HttpPost]
        [Route("update-mobile")]
        public async Task<IActionResult> UpdateMobile([FromBody] ContactUpdateMobileRequest request)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage));
                logger.LogError("Invalid request. {message}", message);
                return BadRequest(new ErrorModel("Invalid requests."));
            }

            var response = await contactService.UpdateMobile(request);

            if (response?.Error != null)
            {
                return BadRequest(response.Error);
            }

            if (response?.Data == null)
            {
                return BadRequest(new ErrorModel("User not found"));
            }

            return Ok(response.Data);
        }
    }
}
