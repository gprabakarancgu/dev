﻿namespace ASQA.Identity.API.Services
{
    public class B2COptions
    {
        public const string B2C = "B2C";
        public string Issuer { get; set; }
    }
}
