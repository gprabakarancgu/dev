﻿using ASQA.Identity.API.Models;
using ASQA.Identity.API.Models.Identity.Contact;
using ASQA.Identity.API.Models.Identity.ImpactedIndividual;
using ASQA.Identity.Data;
using Microsoft.Extensions.Options;
using System.Text.Json;
using System.Text.Json.Nodes;
using ASQA.Identity.Data.Model;

namespace ASQA.Identity.API.Services;

public class ContactService : IContactService
{
    protected IDataverseClient DataverseClient;
    private readonly ILogger<ContactService> logger1;
    private readonly DataverseOptions dataverseOptions;
    private readonly string b2cIssuer;

    public ContactService(IDataverseClient dataverseClient,
        ILogger<ContactService> logger, IOptions<B2COptions> b2cOptions, IOptions<DataverseOptions> dataverseOptions)
    {
        logger1 = logger;
        this.dataverseOptions = dataverseOptions.Value;
        DataverseClient = dataverseClient;
        this.b2cIssuer = b2cOptions.Value.Issuer;
        if (string.IsNullOrEmpty(b2cIssuer))
        {
            throw new ArgumentNullException(nameof(b2cIssuer));
        }
    }

    public async Task<Response<Contact>> Verify(ContactVerificationRequest request)
    {
        var response = new Response<Contact>();

        // TODO: Remove this when Impacted Individuals using the generic ARN
        var impactedIndividual = await GetImpactedIndividualContactByArn(request.Arn);

        var contact = impactedIndividual?.Item1;
        var isImpactedIndividual = contact != null;

        if (contact == null)
        {
            contact = await GetContactByArn(request.Arn);
            if (contact == null)
            {
                response.Error = new ErrorModel("There is no matching record for the ASQA Reference number.");
                return response;
            }
        }

        var externalIdentity = await GetExternalIdentityByContactId(contact.ContactId);
        if (externalIdentity != null)
        {
            response.Error =
                new ErrorModel($"An account has already been created with this email. You can log in with the email address.");
            return response;
        }

        //var roles = await GetRolesAsync(contact.ContactId);
        //if (roles.Any(r => r.Key == dataverseOptions.ImpactedIndividualRoleId))
        //{
        //    contact.IsImpactedIndividual = true;
        //}
        contact.IsImpactedIndividual = isImpactedIndividual;
        response.Data = contact;

        return response;
    }

    public async Task<Response<Contact>?> Link(ContactLinkRequest request)
    {
        var response = new Response<Contact>();

        var externalIdentity = await GetExternalIdentityByContactId(request.ContactId);
        if (externalIdentity != null)
        {
            response.Error = new ErrorModel($"An account has already been created with this email. You can log in with the email address.");
            return response;
        }

        response = await CreateExternalIdentity(request.ContactId, request.ObjectId);
        if (response?.Error != null)
        {
            return response;
        }

        var contact = await GetContact(request.ContactId);
        if (contact == null)
        {
            response = new Response<Contact>
            {
                Error = new ErrorModel("There is no matching record found.")
            };
            return response;
        }

        response = await UpdateContact(request.ContactId, request.ObjectId, request.Email, contact);
        if (response?.Error != null)
        {
            return response;
        }

        return response;
    }

    public async Task<Response<Contact>?> UpdateEmail(ContactUpdateEmailRequest request)
    {
        var response = new Response<Contact>();

        var contact = await GetContact(request.ContactId);
        if (contact == null)
        {
            response.Error = new ErrorModel("There is no matching record found.");
            return response;
        }

        response = await UpdateEmail(request.ContactId, request.Email, contact);
        if (response?.Error != null)
        {
            return response;
        }

        return response;
    }

    public async Task<Response<Contact>?> UpdateMobile(ContactUpdateMobileRequest request)
    {
        var response = new Response<Contact?>();

        var contact = await GetContact(request.ContactId);

        if (contact == null)
        {
            response.Error = new ErrorModel("There is no matching record found.");
            return response!;
        }

        response = await UpdateMobile(contact.ContactId, request.Mobile, contact);
        if (response?.Error != null)
        {
            return response!;
        }

        return response!;
    }

    private async Task<Contact?> GetContactByArn(string arn)
    {
        var contacts = await DataverseClient.ListAsync(
            "contacts",
            new RequestOptions
            {
                Filter = $"asqa_contactid eq '{arn}'",
                Select = string.Join(',', DataversConstats.ContactAttrNames)
            },
            convert: (e, _) => e.Deserialize<Contact>(new JsonSerializerOptions()
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                Converters = { new DataverseImpactedIndividualContactConverter() }
            }));
        return contacts.FirstOrDefault();
    }

    private async Task<Response<Contact?>> CreateContact(string email, string firstName, string lastName)
    {
        var dynamicJsonNode = new JsonObject
        {
            ["firstname"] = firstName,
            ["lastname"] = lastName,
            ["emailaddress1"] = email
        };
        var createContactJson = dynamicJsonNode.ToJsonString(new JsonSerializerOptions { WriteIndented = true });

        var createContactResponse = await DataverseClient.PostAsync("contacts", createContactJson,
            select: string.Join(',', DataversConstats.ContactAttrNames), withRepresentation: true);

        if (!createContactResponse.IsSuccessStatusCode)
        {
            logger1.LogError(new Exception(
                    $"Status: {createContactResponse.StatusCode} Message: {await createContactResponse.Content.ReadAsStringAsync()}"),
                "Failed to update contact");
            return new Response<Contact?> { Error = new ErrorModel("Unexpected error, please try again later. If the problem continues, contact ASQA for assistance.") };
        }
        var contactStream = await createContactResponse.Content.ReadAsStreamAsync();

        var contact = await JsonSerializer.DeserializeAsync<Contact>(contactStream, options: new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            Converters = { new DataverseImpactedIndividualContactConverter() }
        });
        return new Response<Contact?> { Data = contact };
    }

    private async Task<IEnumerable<Contact>> GetContacts(string email)
    {
        var contacts = await DataverseClient.ListAsync(
            "contacts",
            new RequestOptions
            {
                Filter = $"emailaddress1 eq '{email}'",
                Select = string.Join(',', DataversConstats.ContactAttrNames)
            },
            convert: (e, _) => e.Deserialize<Contact>(new JsonSerializerOptions()
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                Converters = { new DataverseImpactedIndividualContactConverter() }
            }));
        return contacts!;
    }

    protected async Task<Contact?> GetContact(string contactId)
    {
        var contacts = await DataverseClient.ListAsync(
            "contacts",
            new RequestOptions
            {
                Filter = $"contactid eq '{contactId}'",
                Select = string.Join(',', DataversConstats.ContactAttrNames)
            },
            convert: (e, _) => e.Deserialize<Contact>(new JsonSerializerOptions()
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                Converters = { new DataverseImpactedIndividualContactConverter() }
            }));
        return contacts.FirstOrDefault();
    }

    protected async Task AssignRole(string contactId, string roleId)
    {
        var json = @$"{{
    ""@odata.id"": ""{DataverseClient.BaseAddress}mspp_webroles({roleId})""
}}";
        var response = await DataverseClient.PostAsync("contacts", json, "powerpagecomponent_mspp_webrole_contact/$ref", contactId, CancellationToken.None);
    }

    protected async Task<IDictionary<string, string>> GetRolesAsync(string contactId)
    {
        var roles = await DataverseClient.ListAsync(
            "contacts",
            new RequestOptions
            {
                SubEntitySetName = "powerpagecomponent_mspp_webrole_contact",
                ItemId = Guid.Parse(contactId)
            },
            convert: (e, _) => new KeyValuePair<string, string>(e.GetProperty("powerpagecomponentid").GetString()!,
                e.GetProperty("name").GetString()!));
        return roles.ToDictionary(k => k.Key, k => k.Value);
    }


    private async Task<Response<Contact>> UpdateEmail(string contactId, string email, Contact contact)
    {
        contact.SetEmail(email);

        var updateRequest = JsonNode.Parse(@$"{{
        ""{DataversConstats.EmailAttrName}"": ""{email}"",
        ""adx_identity_emailaddress1confirmed"": true
    }}");
        if (!string.IsNullOrEmpty(contact.Email2))
        {
            updateRequest![DataversConstats.Email2AttrName] = contact.Email2;
        }

        if (!string.IsNullOrEmpty(contact.Email2))
        {
            updateRequest![DataversConstats.Email3AttrName] = contact.Email3;
        }

        var updateEmailResponse = await DataverseClient.PatchAsync("contacts",
            updateRequest!.ToJsonString(), contactId);

        if (!updateEmailResponse.IsSuccessStatusCode)
        {
            logger1.LogError(new Exception(
                    $"Status: {updateEmailResponse.StatusCode} Message: {await updateEmailResponse.Content.ReadAsStringAsync()}"),
                "Failed to update contact");
            return new Response<Contact> { Error = new ErrorModel("Unexpected error, please try again later. If the problem continues, contact ASQA for assistance.") };
        }

        return new Response<Contact> { Data = contact };
    }

    private async Task<Response<Contact?>> UpdateMobile(string contactId, string mobile, Contact contact)
    {
        contact.SetMobile(mobile);

        var updateRequest = JsonNode.Parse(@$"{{
        ""{DataversConstats.MobileAttrName}"": ""{mobile}"",
        ""adx_identity_mobilephoneconfirmed"": true
    }}");

        if (!string.IsNullOrEmpty(contact.Mobile2))
        {
            updateRequest![DataversConstats.Mobile2AttrName] = contact.Mobile2;
        }

        if (!string.IsNullOrEmpty(contact.Mobile3))
        {
            updateRequest![DataversConstats.Mobile3AttrName] = contact.Mobile3;
        }

        var updateEmailResponse = await DataverseClient.PatchAsync("contacts",
            updateRequest!.ToJsonString(), contactId);

        if (!updateEmailResponse.IsSuccessStatusCode)
        {
            logger1.LogError(new Exception(
                    $"Status: {updateEmailResponse.StatusCode} Message: {await updateEmailResponse.Content.ReadAsStringAsync()}"),
                "Failed to update contact");
            return new Response<Contact?> { Error = new ErrorModel("Unexpected error, please try again later. If the problem continues, contact ASQA for assistance.") };
        }

        return new Response<Contact?> { Data = contact };
    }

    protected async Task<Contact?> GetExternalIdentityByContactId(string contactId)
    {
        var externalIdentities = await DataverseClient.ListAsync(
            "adx_externalidentities",
            new RequestOptions
            {
                Top = 1,
                Expand = "adx_contactid($select=contactid,emailaddress1)",
                Filter = $"adx_contactid/contactid eq '{contactId}'",
                Select = "adx_externalidentityid"
            },
            convert: (e, _) =>
            {
                if (!e.TryGetProperty("adx_contactid", out var impactedIndividual))
                {
                    return null;
                }
                ;
                return impactedIndividual.Deserialize<Contact>(new JsonSerializerOptions()
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                    Converters = { new DataverseImpactedIndividualContactConverter() }
                });
            });
        return externalIdentities.FirstOrDefault();
    }

    protected async Task<Response<Contact>> CreateExternalIdentity(string contactId, string objectId)
    {
        var createExternalIdBody = @$"{{
        ""adx_contactid@odata.bind"": ""/contacts({contactId})"",
        ""adx_identityprovidername"": ""{b2cIssuer}"",
        ""adx_username"": ""{objectId}"",
        ""adx_externalidentityid"": ""{Guid.NewGuid()}"",
        ""statuscode"": 1
    }}";
        var createExternalIdResponse = await DataverseClient.PostAsync("adx_externalidentities",
            createExternalIdBody, subEntitySetName: null, key: null, select: null, expand: "adx_contactid($select=contactid,emailaddress1,emailaddress2,emailaddress3)");
        var str = await createExternalIdResponse.Content.ReadAsStringAsync();
        if (!createExternalIdResponse.IsSuccessStatusCode)
        {
            logger1.LogError(new Exception(
                    $"Status: {createExternalIdResponse.StatusCode} Message: {await createExternalIdResponse.Content.ReadAsStringAsync()}"),
                "Failed to create external identity");
            return new Response<Contact> { Error = new ErrorModel("Unexpected error, please try again later. If the problem continues, contact ASQA for assistance.") };
        }

        return new Response<Contact>();
    }

    protected async Task<Response<Contact>?> UpdateContact(string contactId, string objectId, string email, Contact contact)
    {
        contact.SetEmail(email);

        var updateRequest = JsonNode.Parse(@$"{{
        ""{DataversConstats.EmailAttrName}"": ""{email}"",
        ""adx_identity_emailaddress1confirmed"": true,
        ""adx_identity_username"": ""{objectId}"",
        ""adx_identity_logonenabled"": true,
        ""adx_identity_lockoutenabled"": true,
        ""adx_identity_securitystamp"": ""{Guid.NewGuid()}"",
        ""adx_profilemodifiedon"": ""{DateTime.UtcNow:yyyy-MM-dd'T'HH:mm:ss'Z'}""
    }}");
        if (!string.IsNullOrEmpty(contact.Email2))
        {
            updateRequest![DataversConstats.Email2AttrName] = contact.Email2;
        }

        if (!string.IsNullOrEmpty(contact.Email2))
        {
            updateRequest![DataversConstats.Email3AttrName] = contact.Email3;
        }

        var updateResponse = await DataverseClient.PatchAsync("contacts",
            updateRequest!.ToJsonString(), contactId);

        if (!updateResponse.IsSuccessStatusCode)
        {
            logger1.LogError(new Exception(
                    $"Status: {updateResponse.StatusCode} Message: {await updateResponse.Content.ReadAsStringAsync()}"),
                "Failed to update contact");
            return new Response<Contact> { Error = new ErrorModel("Unexpected error, please try again later. If the problem continues, contact ASQA for assistance.") };
        }

        return new Response<Contact> { Data = contact };
    }

    protected async Task<Tuple<Contact?, string?>?> GetImpactedIndividualContactByArn(string arn)
    {
        JsonArrayResponse<Tuple<Contact?, string?>> impactedIndividualContacts = await DataverseClient.ListAsync<Tuple<Contact?, string?>>(
            "asqa_qiarns",
            new RequestOptions
            {
                Top = 1,
                Expand = $"asqa_impactedindividual($select={string.Join(',', DataversConstats.ContactAttrNames)})",
                Filter = $"asqa_name eq '{arn}'",
                Select = "asqa_name"
            },
            convert: (e, _) =>
            {
                if (!e.TryGetProperty("asqa_impactedindividual", out var impactedIndividual))
                {
                    throw new ArgumentNullException("asqa_impactedindividual");
                }

                impactedIndividual.TryGetProperty(DataversConstats.BirthDateAttrName, out var birthDateElement);
                birthDateElement.TryGetsString(out var dateOfBirth);

                return new Tuple<Contact?, string?>(impactedIndividual.Deserialize<Contact>(new JsonSerializerOptions()
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                    Converters = { new DataverseImpactedIndividualContactConverter() }
                }), dateOfBirth);
            });
        return impactedIndividualContacts.FirstOrDefault();
    }

}