param (
    [Parameter(Mandatory = $true)][string]$env,
    [Parameter(Mandatory = $false)][string]$policiesFolder = "b2c-policies", # path to XML policies (current folder is default)
    [Parameter(Mandatory = $true)][Alias('a')][string]$appId,
    [Parameter(Mandatory = $true)][Alias('k')][string]$appKey,
    [Parameter(Mandatory = $false)][Alias('l')][bool]$isLocal = $true                                                                                        # -"-
)

$compiledPoliciesFolder = "$policiesFolder\environments\$env\policies"
$jsonFilePath = "$policiesFolder\environments\$env\$env.json"


$keyValues = Get-Content $jsonFilePath | ConvertFrom-Json
$tenantName =  ($keyValues.PSObject.Properties | Where-Object { $_.Name -eq 'TenantName' }).Value
$tenantId = ($keyValues.PSObject.Properties | Where-Object { $_.Name -eq 'TenantId' }).Value

if ($isLocal -eq $true) {
    $proxy = New-Object System.Net.WebProxy("http://userproxy.dmz.ige:8080")
    $proxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials
    [System.Net.WebRequest]::DefaultWebProxy = $proxy
}
$body = @{grant_type = "client_credentials"; scope = "https://graph.microsoft.com/.default"; client_id = $appId; client_secret = $appKey }

$response = Invoke-RestMethod -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Method Post -Body $body

$accessToken = $response.access_token

# get current path as default
if ( "" -eq $compiledPoliciesFolder ) {
    $compiledPoliciesFolder = (get-location).Path
}

# invoke the Graph REST API to upload the Policy
Function UploadPolicy( [string]$PolicyId, [string]$PolicyData) {
    write-host "Uploading policy $PolicyId..."
    $url = "https://graph.microsoft.com/beta/trustFramework/policies/$PolicyId/`$value"
    $resp = Invoke-RestMethod -Method PUT -Uri $url -ContentType "application/xml" -Headers @{'Authorization' = "Bearer $($accessToken)" } -Body $PolicyData
    write-host $resp.TrustFrameworkPolicy.PublicPolicyUri
}

# process each Policy object in the array. For each that has a BasePolicyId, follow that dependency link
# first call has to be with BasePolicyId null (base/root policy) for this to work
Function ProcessPolicies( $arrP, $BasePolicyId ) {
    foreach ( $p in $arrP ) {
        if ( $p.xml.TrustFrameworkPolicy.TenantId -ne $tenantName ) {
            write-output "$($p.PolicyId) has wrong tenant configured $($p.xml.TrustFrameworkPolicy.TenantId) - skipped"
        }
        else {
            if ( $BasePolicyId -eq $p.BasePolicyId -and $p.Uploaded -eq $false ) {                
                UploadPolicy $p.PolicyId $p.PolicyData  # upload this one
                $p.Uploaded = $true                
                ProcessPolicies $arrP $p.PolicyId       # process all policies that has a ref to this one
            }
        }
    }
}

# enumerate all XML files in the specified folders and create a array of objects with info we need
$files = get-childitem -path $compiledPoliciesFolder -name -include *.xml | Where-Object { ! $_.PSIsContainer }
$arr = @()
foreach ( $file in $files ) {
    $PolicyFile = (Join-Path -Path $compiledPoliciesFolder -ChildPath $file)
    write-host "Reading file $PolicyFile..."
    $PolicyData = Get-Content $PolicyFile
    [xml]$xml = $PolicyData
    if ($null -ne $xml.TrustFrameworkPolicy -and $xml.TrustFrameworkPolicy.PolicyId) {
        $policy = New-Object System.Object
        $policy | Add-Member -type NoteProperty -name "PolicyId" -Value $xml.TrustFrameworkPolicy.PolicyId
        $policy | Add-Member -type NoteProperty -name "BasePolicyId" -Value $xml.TrustFrameworkPolicy.BasePolicy.PolicyId
        $policy | Add-Member -type NoteProperty -name "Uploaded" -Value $false
        $policy | Add-Member -type NoteProperty -name "FilePath" -Value $PolicyFile
        $policy | Add-Member -type NoteProperty -name "xml" -Value $xml
        $policy | Add-Member -type NoteProperty -name "PolicyData" -Value $PolicyData
        $policy | Add-Member -type NoteProperty -name "HasChildren" -Value $null
        $arr += $policy
    }
}

# find out who is/are the root in inheritance chain so we know which to upload first
foreach ( $p in $arr ) {
    $p.HasChildren = ( $null -ne ($arr | Where-Object { $_.PolicyId -eq $p.BasePolicyId }) ) 
}

# upload policies - start with those who are root(s)
foreach ( $p in $arr ) {
    if ( $p.HasChildren -eq $False ) {
        ProcessPolicies $arr $p.BasePolicyId
    }
}

# SIG # Begin signature block
# MIIPcAYJKoZIhvcNAQcCoIIPYTCCD10CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUNSpJxmElDw0+skq5SPQzTq8z
# QxKgggzEMIIGOjCCBSKgAwIBAgITQwAAAAIGvAm/42kSbAAAAAAAAjANBgkqhkiG
# 9w0BAQsFADAlMSMwIQYDVQQDExpBdXN0cmFsaWFuIEdvdmVybm1lbnQgUm9vdDAe
# Fw0yMzA3MTIwODUzMzZaFw0zMzA3MTIwOTAzMzZaMF4xFDASBgoJkiaJk/IsZAEZ
# FgRlbmV0MRswGQYKCZImiZPyLGQBGRYLYXBwbGljYXRpb24xKTAnBgNVBAMTIEF1
# c3RyYWxpYW4gR292ZXJubWVudCBQcm9kdWN0aW9uMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAomBgucfMN/T+RN/nF7nBYVJBWJRFnLshf1/IStob/p/n
# 6WoLmP+6BIUmU6oMl9XyIqsZsBKruBpnxUdsBeGzYTsl5nAFG6UE35cYEiqZh5v/
# n6OW8ZEeVustIyWaWL1xCtZEVHLq4RqP0I6eqOewhhvi/UhTqrAvPKlbRBl0eNWP
# PmFzuSWkN/5J3Gbv4u9WLrkmBQSqGpEGxM6IGOQU3jAxVvAPXIgSFX7npWmo5aTo
# HBEM96YZsAPQIkbFmDJcjjdjrAGS/LRmnmgIxQqqhlxA/csZzyIp7yOZYBYZ/BFm
# V39lvWHvdp8Rl8ZgVcGyMNIO8j7KG6Mt6weH1aIitQIDAQABo4IDKDCCAyQwEAYJ
# KwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFOtHP6kdjFcY7sjL3q9dGSJtMjJ6MBkG
# CSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8E
# BTADAQH/MB8GA1UdIwQYMBaAFCZEV2b+sP4JDEjk6k6F30PWRTx2MIIBTAYDVR0f
# BIIBQzCCAT8wggE7oIIBN6CCATOGgdFsZGFwOi8vL0NOPUF1c3RyYWxpYW4lMjBH
# b3Zlcm5tZW50JTIwUm9vdCxDTj1BdXN0R292Um9vdCxDTj1DRFAsQ049UHVibGlj
# JTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbiwl
# MjBEQz1hcHBsaWNhdGlvbixEQz1lbmV0P2NlcnRpZmljYXRlUmV2b2NhdGlvbkxp
# c3Q/YmFzZT9vYmplY3RDbGFzcz1jUkxEaXN0cmlidXRpb25Qb2ludIZdaHR0cDov
# L0VEQ19Qcm9kdWN0aW9uX0NBLmhvc3RzLmFwcGxpY2F0aW9uLmVuZXQvQ2VydEVu
# cm9sbC9BdXN0cmFsaWFuJTIwR292ZXJubWVudCUyMFJvb3QuY3JsMIIBRQYIKwYB
# BQUHAQEEggE3MIIBMzCBxQYIKwYBBQUHMAKGgbhsZGFwOi8vL0NOPUF1c3RyYWxp
# YW4lMjBHb3Zlcm5tZW50JTIwUm9vdCxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIw
# U2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbiwlMjBEQz1hcHBs
# aWNhdGlvbixEQz1lbmV0P2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1j
# ZXJ0aWZpY2F0aW9uQXV0aG9yaXR5MGkGCCsGAQUFBzAChl1odHRwOi8vRURDX1By
# b2R1Y3Rpb25fQ0EuaG9zdHMuYXBwbGljYXRpb24uZW5ldC9DZXJ0RW5yb2xsL0F1
# c3RyYWxpYW4lMjBHb3Zlcm5tZW50JTIwUm9vdC5jcnQwDQYJKoZIhvcNAQELBQAD
# ggEBAI06Xi/l2fByQnLQokm2WVI9a/1Lgd/s1+SfZSld6NiyoifYmba75GRt7HSG
# kxC+QvbhUrj9nWZJkrUzNCSNJ9tJG49OP0JvLk9DJoKCeL8oCvIybduut1+JITWg
# ItHx+d/N+/xo1Mkv6Dvhn6A3lwAPzXSeJZ5jTnzwLdza5rDNV0XTdJtxpBsRF+B+
# lZQIsH+Ym3HbngaY+xe9DQ2B2aWhU1IM2jeqyx2tvw5EM7lg68LY1G3OCgTkBc1V
# 3dOVYgQTtqoGTO9hlElxlhwCAht3z3eECy4UppEksOORAel7hDibbMHeZTikZyMY
# 1SGapcF6WX6va2Sc3YqkYTttUBMwggaCMIIFaqADAgECAhNwAAAAC//S3VJi1WrZ
# AAAAAAALMA0GCSqGSIb3DQEBCwUAMF4xFDASBgoJkiaJk/IsZAEZFgRlbmV0MRsw
# GQYKCZImiZPyLGQBGRYLYXBwbGljYXRpb24xKTAnBgNVBAMTIEF1c3RyYWxpYW4g
# R292ZXJubWVudCBQcm9kdWN0aW9uMB4XDTIzMDgzMTIyNDY0OFoXDTI4MDgyOTIy
# NDY0OFowJzElMCMGA1UEAxMcREVXUiBDb2RlIFNpZ25pbmcgUHJvZHVjdGlvbjCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKKeht0lg0CeBtMASalbHHAZ
# 2h7JMKjDe/BCbJqPTFVRC0Yg1Ws1m92CcNyOwbvtLMNVyFasyUd4RPxOYfZCZyMe
# TdlXpDKPBv7+2ZZinqyjjoaIJJn7ZegNq+PmdUOXxwb/OxedG5cyYoI4kaEhqrpE
# p1F7NVTF+fmfcfiDvSW1vIS8kgC2aH8MH0hbETdY0YyQikclJoKtAd0P11a+gYfT
# Mkc+EjMhKfyBhFYHmEcnaazemEIWVRAqjfdpoZIs1Mu694OZpXo/yY3a+cRUlho0
# LOYb3VIXxadQjW6+y0ZQvoH6WQ/cPxWKW9ZovJyt781yj1irHfEQWA4CkZ8vvQEC
# AwEAAaOCA24wggNqMDwGCSsGAQQBgjcVBwQvMC0GJSsGAQQBgjcVCPL9eIaKrxKG
# vYM3hc/tY4S6rywRgsqNcIbExwcCAWQCAQYwEwYDVR0lBAwwCgYIKwYBBQUHAwMw
# DgYDVR0PAQH/BAQDAgeAMBsGCSsGAQQBgjcVCgQOMAwwCgYIKwYBBQUHAwMwHQYD
# VR0OBBYEFK+ZLLkrr3fr5g1YfAaapzoSBBF9MB8GA1UdIwQYMBaAFOtHP6kdjFcY
# 7sjL3q9dGSJtMjJ6MIIBVAYDVR0fBIIBSzCCAUcwggFDoIIBP6CCATuGgdNsZGFw
# Oi8vL0NOPUF1c3RyYWxpYW4lMjBHb3Zlcm5tZW50JTIwUHJvZHVjdGlvbixDTj1F
# UFJJU0VDMjA1LENOPUNEUCxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1T
# ZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPWFwcGxpY2F0aW9uLERDPWVuZXQ/
# Y2VydGlmaWNhdGVSZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdENsYXNzPWNSTERp
# c3RyaWJ1dGlvblBvaW50hmNodHRwOi8vRURDX1Byb2R1Y3Rpb25fQ0EuaG9zdHMu
# YXBwbGljYXRpb24uZW5ldC9DZXJ0RW5yb2xsL0F1c3RyYWxpYW4lMjBHb3Zlcm5t
# ZW50JTIwUHJvZHVjdGlvbi5jcmwwggFOBggrBgEFBQcBAQSCAUAwggE8MIHIBggr
# BgEFBQcwAoaBu2xkYXA6Ly8vQ049QXVzdHJhbGlhbiUyMEdvdmVybm1lbnQlMjBQ
# cm9kdWN0aW9uLENOPUFJQSxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1T
# ZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPWFwcGxpY2F0aW9uLERDPWVuZXQ/
# Y0FDZXJ0aWZpY2F0ZT9iYXNlP29iamVjdENsYXNzPWNlcnRpZmljYXRpb25BdXRo
# b3JpdHkwbwYIKwYBBQUHMAKGY2h0dHA6Ly9FRENfUHJvZHVjdGlvbl9DQS5ob3N0
# cy5hcHBsaWNhdGlvbi5lbmV0L0NlcnRFbnJvbGwvQXVzdHJhbGlhbiUyMEdvdmVy
# bm1lbnQlMjBQcm9kdWN0aW9uLmNydDANBgkqhkiG9w0BAQsFAAOCAQEAho9YA8dL
# RRSy2qcE9SuOcUGwlvphIVb4j1P8amNQa6WvJUA1+sLoFTAc/rNaCSu57N9ky5NA
# ghBDF9YE1508DJsAv2jsBWef/HySsY6BYW/nlIv2ZYMNNZJc78QOld9+jQr3Pt6W
# rH1zlKtpvMNvytjlT5P5LnybiCXmWYRaG4UZIYWC9U6Cl3kaeh14/nGAhd+IP+O9
# +0O4p9HuBkDNY6CFeDACXwAjB2pY0MTLd3dg1YQ8JQGpJTgmuge7TA45lY16YY7c
# 9wn7WaXk7VcemLRWkfgW4vJRwUU66oSCP0ofvr8Br2xqklzj4BBjLUhDdXyqOz/6
# mwryjFZ5tRaMTTGCAhYwggISAgEBMHUwXjEUMBIGCgmSJomT8ixkARkWBGVuZXQx
# GzAZBgoJkiaJk/IsZAEZFgthcHBsaWNhdGlvbjEpMCcGA1UEAxMgQXVzdHJhbGlh
# biBHb3Zlcm5tZW50IFByb2R1Y3Rpb24CE3AAAAAL/9LdUmLVatkAAAAAAAswCQYF
# Kw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkD
# MQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJ
# KoZIhvcNAQkEMRYEFGbjY+08jzDHQZZFLYSVokvImeKwMA0GCSqGSIb3DQEBAQUA
# BIIBAB0cAkhVBKBjZDAjOUEllPta+y4Lm1So9aZwwQLRBzDhM3MkCwXWv21BNXWN
# tzb4bnUESx/wSZAWH0ohqsAGxwfUss6DThZLaOLgav/PtlTP1N1EoHOhC/eFvoIq
# ZT6Zi2UsGkI3A0/P60020dO8pNLirhD7wYWkXSRm7EOkjqnFYs28YF5+FERRRO+Y
# FWoVuVlIBBc7ICwiHVJ5y2D1wlXYMK07lgrlZvMXXw8vYtYHpqii7S/ngC5sIeLj
# 0r3oWH6jFAgDspDP1mmLmMDDhBntnK/bJC1EEF2vUN8tU9vEjtBPGhbed/8QFzhC
# 41WbiTwx9qF9mZjOxkicUOg95SQ=
# SIG # End signature block
