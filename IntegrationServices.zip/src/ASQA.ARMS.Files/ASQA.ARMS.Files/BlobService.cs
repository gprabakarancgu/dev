﻿using Azure.Storage.Blobs;

namespace ASQA.ARMS.Files;

public class BlobService : IFileSource
{
    private readonly BlobClient _blobClient;

    public BlobService(string filePath, BlobServiceClient serviceClient)
    {
        var filePathParts = filePath.Split('/');
        if (filePathParts.Length < 2)
        {
            throw new ArgumentException("Invalid file path");
        }
        var blobContainerClient = serviceClient.GetBlobContainerClient(filePathParts[0]);
        _blobClient = blobContainerClient.GetBlobClient(string.Join('/', filePathParts.Skip(1)));
    }

    public async Task<FileProperties> GetFilePropertiesAsync()
    {
        var properties = await _blobClient.GetPropertiesAsync();
        return new FileProperties { Size = properties.Value.ContentLength };
    }

    public async Task<Stream> OpenAsync()
    {
        var blobStream = await _blobClient.OpenReadAsync();
        return blobStream;
    }

    public async Task<Stream> DownloadAsync()
    {
        var blobStream = new MemoryStream();
        await _blobClient.DownloadToAsync(blobStream);
        return blobStream;
        blobStream.Seek(0, SeekOrigin.Begin);
        return blobStream;
    }
}