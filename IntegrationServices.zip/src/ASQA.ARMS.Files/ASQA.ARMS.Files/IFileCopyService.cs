﻿namespace ASQA.ARMS.Files;

public interface IFileCopyService
{
    Task<long> CopyFileAsync(string sourcePath, string destinationPath);
}