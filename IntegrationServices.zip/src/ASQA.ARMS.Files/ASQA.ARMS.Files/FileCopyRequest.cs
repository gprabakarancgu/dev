namespace ASQA.ARMS.Files;

public class FileCopyRequest
{
    public string SourceFilePath { get; set; }
    public string DestinationFilePath { get; set; }
}