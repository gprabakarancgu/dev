﻿namespace ASQA.ARMS.Files;

public interface ISharePointAuthenticationService
{
    Task<string?> AcquireAsyncTokenAsync();
}