﻿namespace ASQA.ARMS.Files;

public interface IFileSource
{
    Task<FileProperties> GetFilePropertiesAsync();
    Task<Stream> OpenAsync();
    Task<Stream> DownloadAsync();
}