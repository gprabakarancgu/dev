﻿namespace ASQA.ARMS.Files;

public class FileCopyOptions
{
    public int ChunkSizeInMb { get; set; } = 4;
    public int ChunkCopyThresholdInMb { get; set; } = 4;
}