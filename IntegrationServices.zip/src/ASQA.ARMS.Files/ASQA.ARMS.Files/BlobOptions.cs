﻿namespace ASQA.ARMS.Files;

public class BlobOptions
{
    public string ServiceUrl { get; set; }
}