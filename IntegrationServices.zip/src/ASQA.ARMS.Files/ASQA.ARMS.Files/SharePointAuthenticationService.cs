﻿using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;

namespace ASQA.ARMS.Files;

public class SharePointAuthenticationService(
    IHttpClientFactory httpClientFactory,
    IOptions<SharePointOptions> sharePointOptions)
    : ISharePointAuthenticationService
{
    private readonly HttpClient _httpClient = httpClientFactory.CreateClient("SharePointAuth");
    private readonly SharePointOptions _sharePointOptions = sharePointOptions.Value;

    public async Task<string?> AcquireAsyncTokenAsync()
    {
        var body =
            $"resource={_sharePointOptions.AuthResource}&client_id={_sharePointOptions.AuthClientId}&client_secret={_sharePointOptions.AuthClientSecret}&grant_type=client_credentials";
        using var stringContent = new StringContent(body, Encoding.UTF8, "application/x-www-form-urlencoded");
        var result = await _httpClient.PostAsync(_sharePointOptions.AuthUrl, stringContent);
        var tokenResult = await result.Content.ReadFromJsonAsync<JsonDocument>() ?? throw new ArgumentNullException($"SharePointToken");
        var token = tokenResult.RootElement.GetProperty("access_token").ToString();
        return token;
    }
}