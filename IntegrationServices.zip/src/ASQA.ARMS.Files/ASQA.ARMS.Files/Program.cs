using ASQA.ARMS.Files;
using Azure.Core;
using Azure.Identity;
using Azure.Storage.Blobs;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.Latency;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.ApplicationInsights;
using Microsoft.Extensions.Options;
using System.Net;

#if DEBUG

HttpClient.DefaultProxy = new WebProxy(new Uri("http://proxy.dmz.ige:8080"), true,
    new[] { ".vault.azure.net", ".queue.core.windows.net" });

#endif

var builder = FunctionsApplication.CreateBuilder(args);
var environment = builder.Configuration["FuncEnvironment"];
if (string.IsNullOrEmpty(environment))
{
    throw new ArgumentNullException(nameof(environment));
}

var keyVaultUrl = $"https://{builder.Configuration["KeyVaultName"]}.vault.azure.net/";

TokenCredential azureCredential = new DefaultAzureCredential();

#if DEBUG

azureCredential = new VisualStudioCredential();

#endif
builder.Configuration.AddAzureKeyVault(
    new Uri(keyVaultUrl),
    azureCredential);
builder.Configuration.AddJsonFile("appsettings.json", false, true);
builder.Configuration.AddJsonFile($"appsettings.{environment}.json", false, true);


builder.ConfigureFunctionsWebApplication();
//builder.Services.AddSingleton<QueueCorrelationMiddleware>();
builder.UseMiddleware<QueueCorrelationMiddleware>();

builder.Services
    .AddApplicationInsightsTelemetryWorkerService()
    .ConfigureFunctionsApplicationInsights();
builder.Services.AddApplicationInsightsTelemetryWorkerService();
builder.Services.AddSingleton<ITelemetryInitializer, ActivityTagTelemetryInitializer>();

builder.Logging.AddFilter<ApplicationInsightsLoggerProvider>(null, LogLevel.Information);

builder.Services.AddOptions();

builder.Services.AddTransient<ProxyHttpClientHandler>();
builder.Services.AddHttpClient("SharePointAuth")
    .ConfigurePrimaryHttpMessageHandler<ProxyHttpClientHandler>();
builder.Services.AddTransient<ISharePointAuthenticationService, SharePointAuthenticationService>();
builder.Services.AddTransient<IFileDestination, SharePointService>();
builder.Services.Configure<SharePointOptions>(builder.Configuration.GetSection("SharePoint"));

builder.Services.Configure<FileCopyOptions>(builder.Configuration.GetSection("FileCopy"));
builder.Services.AddTransient<IFileCopyService, FileCopyService>();
builder.Services.Configure<BlobOptions>(builder.Configuration.GetSection("Blob"));
builder.Services.AddSingleton(provider =>
    new BlobServiceClient(new Uri(provider.GetRequiredService<IOptions<BlobOptions>>().Value.ServiceUrl),
        azureCredential));

builder.Services.AddTransient(provider =>
{
    var fileSource = new Func<string, IFileSource>(filePath =>
        new BlobService(filePath, provider.GetRequiredService<BlobServiceClient>()));
    return fileSource;
});
builder.Services.AddTransient(provider =>
{
    var fileDestination = new Func<string, IFileDestination>(filePath =>
        new SharePointService(filePath, provider.GetRequiredService<IHttpClientFactory>(),
            provider.GetRequiredService<ISharePointAuthenticationService>(),
            provider.GetRequiredService<IOptions<SharePointOptions>>(),
            provider.GetRequiredService<ILogger<SharePointService>>()));
    return fileDestination;
});
builder.Services.AddTransient<IFileDestination, SharePointService>();
builder.Services.AddHttpClient("SharePoint")
    .ConfigurePrimaryHttpMessageHandler<ProxyHttpClientHandler>()
    .AddStandardResilienceHandler(options =>
    {
        // Customize retry
        options.Retry.Delay = TimeSpan.FromSeconds(60);
        options.Retry.MaxRetryAttempts = 3;
        options.Retry.ShouldRetryAfterHeader = false;
        options.Retry.UseJitter = true;

        // Customize attempt timeout
        options.TotalRequestTimeout.Timeout = TimeSpan.FromMinutes(5);
        //options.AttemptTimeout.Timeout = TimeSpan.FromSeconds(2);
    });

builder.Build().Run();