﻿namespace ASQA.ARMS.Files;

public class SharePointOptions
{
    public string AuthResource { get; set; }
    public string AuthClientSecret { get; set; }
    public string AuthClientId { get; set; }
    public string AuthUrl { get; set; }
    public string TenantUrl { get; set; }
    public string SiteName { get; set; }
}