using Microsoft.Azure.Functions.Worker;

namespace ASQA.ARMS.Files;

public class FileCopyFunction(IFileCopyService fileCopyService)
{
    [Function(nameof(FileCopyFunction))]
    public async Task Run([QueueTrigger("file-copy", Connection = "FileCopy")] FileCopyRequest request)
    {
        if (request == null)
        {
            throw new ArgumentNullException(nameof(request));
        }
        await fileCopyService.CopyFileAsync(request.SourceFilePath, request.DestinationFilePath);
    }
}