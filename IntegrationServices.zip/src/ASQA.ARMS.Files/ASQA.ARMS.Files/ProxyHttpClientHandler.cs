﻿using Microsoft.Extensions.Configuration;
using System.Net;

namespace ASQA.ARMS.Files;

public class ProxyHttpClientHandler : HttpClientHandler
{
    public ProxyHttpClientHandler(IConfiguration configuration)
    {
        Proxy = new WebProxy(new Uri(configuration["Proxy:BaseUrl"]!), true, null, new NetworkCredential(
            configuration["Proxy:Username"], configuration["Proxy:Password"],
            "nation"));
    }
}