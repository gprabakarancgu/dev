﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ASQA.ARMS.Files;

public class FileCopyService(
    Func<string, IFileSource> fileSourceFactory,
    Func<string, IFileDestination> fileDestinationFactory,
    IOptions<FileCopyOptions> fileCopyOptions,
    ILogger<FileCopyService> logger) : IFileCopyService
{
    public async Task<long> CopyFileAsync(string sourcePath, string destinationPath)
    {
        var fileSource = fileSourceFactory(sourcePath);
        var fileDestination = fileDestinationFactory(destinationPath);

        var fileProperties = await fileSource.GetFilePropertiesAsync();

        long chunkCopyThresholdInMb = fileCopyOptions.Value.ChunkCopyThresholdInMb * 1024 * 1024;
        if (fileProperties.Size > chunkCopyThresholdInMb)
        {
            await ChunkCopyAsync(fileProperties.Size, fileSource, fileDestination);
        }
        else
        {
            await FileCopyAsync(fileProperties.Size, fileSource, fileDestination);
        }

        return fileProperties.Size;
    }

    private async Task ChunkCopyAsync(long fileSize, IFileSource fileSource, IFileDestination fileDestination)
    {
        var chunkSize = fileCopyOptions.Value.ChunkSizeInMb * 1024 * 1024; // MB
        var numberOfChunks = Math.Ceiling((double)fileSize / chunkSize);
        var offset = 0;
        var i = 0;

        logger.LogInformation($"Downloading blob in chunks... Total Size: {fileSize} bytes, chunk size: {chunkSize}");

        await fileDestination.CreateFileAsync();

        await using var blobStream = await fileSource.OpenAsync();
        var buffer = new byte[chunkSize];
        int bytesRead;
        while ((bytesRead = await blobStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
        {
            logger.LogInformation($"read: {bytesRead} offset: {offset}");

            await fileDestination.CopyChunkAsync(buffer, bytesRead, offset, i == numberOfChunks - 1);

            offset += bytesRead;
            i++;
        }
    }

    private async Task FileCopyAsync(long fileSize, IFileSource fileSource, IFileDestination fileDestination)
    {
        logger.LogInformation($"Downloading blob... Total Size: {fileSize} bytes");
        await using var fileStream = await fileSource.DownloadAsync();
        await fileDestination.CopyFileAsync(fileStream);
    }
}