using System.Diagnostics;
using System.Text.Json;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Middleware;
using Microsoft.Extensions.Logging;

namespace ASQA.ARMS.Files;

public class QueueCorrelationMiddleware(ILogger<QueueCorrelationMiddleware> logger) : IFunctionsWorkerMiddleware
{
    public async Task Invoke(FunctionContext context, FunctionExecutionDelegate next)
    {
        // Check if the function has a QueueTrigger binding
        var isQueueTrigger = context.FunctionDefinition.InputBindings
            .Any(b => b.Value.Type.Equals("QueueTrigger", StringComparison.OrdinalIgnoreCase));

        var correlationId = Guid.NewGuid().ToString();
        if (isQueueTrigger)
        {
            if (context.BindingContext.BindingData["QueueTrigger"] is string queueItem)
            {
                try
                {
                    var jsonDoc = JsonDocument.Parse(queueItem);
                    if (jsonDoc.RootElement.TryGetProperty("correlationId", out var correlationProp))
                    {
                        correlationId = correlationProp.GetString() ?? correlationId;
                    }
                }
                catch (JsonException)
                {
                    logger.LogError("Failed to read the correlation id.");
                }
            }
        }

        // Attach to Activity for distributed tracing
        Activity.Current?.AddTag("CorrelationId", correlationId);
        //context.Items["CorrelationId"] = correlationId;

        var customProperties = new Dictionary<string, object>
        {
            ["CorrelationId"] = correlationId
        };

        using (logger.BeginScope(customProperties))
        {
            await next(context);
        }
    }
}