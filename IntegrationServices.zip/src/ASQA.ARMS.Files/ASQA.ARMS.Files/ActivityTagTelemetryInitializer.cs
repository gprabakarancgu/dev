using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;
using System.Diagnostics;

namespace ASQA.ARMS.Files;

public class ActivityTagTelemetryInitializer : ITelemetryInitializer
{
    public void Initialize(ITelemetry telemetry)
    {
        var activity = Activity.Current;
        if (activity != null)
        {
            var correlationId = FindTagUpChain(activity, "CorrelationId");
            if (!string.IsNullOrEmpty(correlationId))
            {
                telemetry.Context.GlobalProperties["CorrelationId"] = correlationId;

                if (telemetry is RequestTelemetry requestTelemetry)
                {
                    requestTelemetry.Properties["CorrelationId"] = correlationId;
                }

            }
        }
    }


    public static string? FindTagUpChain(Activity? activity, string key)
    {
        while (activity != null)
        {
            var tagValue = activity.Tags.FirstOrDefault(t => t.Key == key).Value;
            if (!string.IsNullOrEmpty(tagValue))
            {
                return tagValue;
            }

            activity = activity.Parent; // Move up the chain
        }

        // If we reach here, no parent had the tag
        return null;
    }

}