﻿namespace ASQA.ARMS.Files;

public class FileProperties
{
    public long Size { get; set; }
}