﻿namespace ASQA.ARMS.Files;

public interface IFileDestination
{
    Task CreateFileAsync();
    Task CopyChunkAsync(byte[] buffer, long bytesRead, long offset, bool isLastBuffer);
    Task CopyFileAsync(Stream fileContent);
}