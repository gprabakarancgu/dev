﻿using System.Net.Http.Headers;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ASQA.ARMS.Files
{
    public class SharePointService : IFileDestination
    {
        private readonly ISharePointAuthenticationService _authenticationService;
        private readonly ILogger<SharePointService> _logger;
        private readonly Guid _uploadId;
        private readonly string _siteName;
        private readonly string _siteUrl;
        private readonly string _folderPath;
        private readonly string _fileName;
        private readonly HttpClient _sharepointHttpClient;

        public SharePointService(string filePath, IHttpClientFactory httpClientFactory,
            ISharePointAuthenticationService authenticationService, IOptions<SharePointOptions> sharePointOptions,
            ILogger<SharePointService> logger)
        {
            _authenticationService = authenticationService;
            _logger = logger;
            _uploadId = Guid.NewGuid();
            var sharePointOptionsVale = sharePointOptions.Value;
            _siteName = sharePointOptionsVale.SiteName;
            _siteUrl = $"{sharePointOptionsVale.TenantUrl.TrimEnd('/')}/sites/{_siteName}";
            var filePathParts = filePath.Split('/');
            if (filePathParts.Length < 2)
            {
                throw new ArgumentException("Invalid file path");
            }

            _folderPath = string.Join('/', filePathParts.SkipLast(1)).TrimStart('/');
            _fileName = filePathParts.Last();
            _sharepointHttpClient = httpClientFactory.CreateClient("SharePoint");
        }

        public async Task CreateFileAsync()
        {
            var sharePointToken = await _authenticationService.AcquireAsyncTokenAsync();
            _sharepointHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", sharePointToken);
            var addResponse = await _sharepointHttpClient.PostAsync(new Uri(
                    $"{_siteUrl}/_api/web/getfolderbyserverrelativeurl('{_folderPath}')/files/add(url='{_fileName}',overwrite=true)"), new StringContent(string.Empty));
            var r = await addResponse.Content.ReadAsStringAsync();
            addResponse.EnsureSuccessStatusCode();
        }

        public async Task CopyChunkAsync(byte[] buffer, long bytesRead, long offset, bool isLastBuffer)
        {
            _logger.LogInformation($"read: {bytesRead} offset: {offset}");
            using HttpContent content = new ByteArrayContent(buffer);
            content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

            var endpoint = offset == 0
                ? $"{_siteUrl}/_api/web/getfilebyserverrelativeurl('/sites/{_siteName}/{_folderPath}/{_fileName}')/StartUpload(uploadId=guid'{_uploadId}')"
                : (isLastBuffer
                    ? $"{_siteUrl}/_api/web/getfilebyserverrelativeurl('/sites/{_siteName}/{_folderPath}/{_fileName}')/FinishUpload(uploadId=guid'{_uploadId}',fileOffset={offset})"
                    : $"{_siteUrl}/_api/web/getfilebyserverrelativeurl('/sites/{_siteName}/{_folderPath}/{_fileName}')/ContinueUpload(uploadId=guid'{_uploadId}',fileOffset={offset})");

            var response = await _sharepointHttpClient.PostAsync(endpoint, content);
            response.EnsureSuccessStatusCode();
        }

        public async Task CopyFileAsync(Stream fileContent)
        {
            var sharePointToken = await _authenticationService.AcquireAsyncTokenAsync();
            _sharepointHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", sharePointToken);
            using HttpContent content = new StreamContent(fileContent);
            content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
            var endpoint =
                $"{_siteUrl}/_api/web/GetFolderByServerRelativeUrl('{_folderPath}')/Files/Add(url='{_fileName}', overwrite=true)";
            var response = await _sharepointHttpClient.PostAsync(endpoint, content);
            response.EnsureSuccessStatusCode();
        }
    }
}
