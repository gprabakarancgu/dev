﻿using ASQA.Identity.Data.Model;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Identity.Client;

namespace ASQA.Identity.Data.Auth
{
    public class ConfidentialClientAuthDelegatingHandler(
        IConfidentialClientApplication app,
        IOptions<DataverseOptions> options,
        ILogger<ConfidentialClientAuthDelegatingHandler> logger)
        : DelegatingHandler
    {
        private readonly IEnumerable<string> scopes = [options.Value.Scope];

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            AuthenticationResult? result = null;
            try
            {
                result = await app.AcquireTokenForClient(scopes)
                                 .ExecuteAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Failed to authenticate to Datavesrse");
                throw;
            }

            if (result != null)
            {
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", result.AccessToken);
            }

            return await base.SendAsync(request, cancellationToken);
        }
    }
}
