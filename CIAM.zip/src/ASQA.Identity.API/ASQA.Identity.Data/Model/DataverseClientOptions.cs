﻿namespace ASQA.Identity.Data.Model
{
    public class DataverseClientOptions
    {
        public const string Dataverse = "Dataverse";
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string TenantId { get; set; }
        public string Scope { get; set; }
        /// <summary>
        /// The Url of the environment: https://org.api.crm.dynamics.com
        /// </summary>
        public string BaseUrl { get; set; }
        /// <summary>
        /// Whether to disable Affinity cookies to gain performance
        /// </summary>
        public bool DisableCookies { get; set; } = false;
        /// <summary>
        /// The version of the service to use
        /// </summary>
        public string Version { get; set; } = "9.2";
        /// <summary>
        /// How long to wait for a timeout
        /// </summary>
        public ushort TimeoutInSeconds { get; set; } = 120;
    }
}
