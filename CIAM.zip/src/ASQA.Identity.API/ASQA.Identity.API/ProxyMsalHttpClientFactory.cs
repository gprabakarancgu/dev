using System.Net;
using Microsoft.Identity.Client;

namespace ASQA.Identity.API;

public class ProxyMsalHttpClientFactory(HttpClient httpClient) : IMsalHttpClientFactory
{
    public HttpClient GetHttpClient()
    {
        return httpClient;
    }
}