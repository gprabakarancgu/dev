using ASQA.Identity.API;
using ASQA.Identity.API.Models;
using ASQA.Identity.API.Models.Identity.Contact;
using ASQA.Identity.API.Models.Identity.ImpactedIndividual;
using ASQA.Identity.API.Services;
using ASQA.Identity.Data;
using ASQA.Identity.Data.Auth;
using ASQA.Identity.Data.Model;
using Azure.Identity;
using FluentValidation;
using FluentValidation.AspNetCore;
using MicroElements.Swashbuckle.FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using Microsoft.Identity.Client;
using Microsoft.Identity.Web;

var builder = WebApplication.CreateBuilder(args);
builder.Configuration.AddAzureKeyVault(
    new Uri($"https://{builder.Configuration["KeyVaultName"]}.vault.azure.net/"),
    new DefaultAzureCredential());

builder.Services.AddApplicationInsightsTelemetry();

builder.Services.AddTransient<ProxyHttpClientHandler>();
builder.Services.AddTransient<LoggingDelegatingHandler>();

builder.Services.AddOptions();
builder.Services.AddTransient<DevAuthDelegatingHandler>();
builder.Services.Configure<DataverseOptions>(
    builder.Configuration.GetSection(DataverseOptions.Dataverse));

builder.Services.AddTransient<IDataverseClient, DataverseClient>();
builder.Services.Configure<B2COptions>(
    builder.Configuration.GetSection(B2COptions.B2C));
builder.Services.AddTransient<IImpactedIndividualService, ImpactedIndividualService>();
builder.Services.AddTransient<IContactService, ContactService>();

builder.Services.AddTransient<ConfidentialClientAuthDelegatingHandler>();
builder.Services.AddHttpClient<IDataverseClient, DataverseClient>()
    .ConfigurePrimaryHttpMessageHandler<ProxyHttpClientHandler>()
    .AddHttpMessageHandler<ConfidentialClientAuthDelegatingHandler>()
    .AddHttpMessageHandler<LoggingDelegatingHandler>();


builder.Services.AddSingleton<ProxyMsalHttpClientFactory>();
builder.Services.AddHttpClient<ProxyMsalHttpClientFactory>()
    .ConfigurePrimaryHttpMessageHandler<ProxyHttpClientHandler>()
    .AddHttpMessageHandler<LoggingDelegatingHandler>();
builder.Services.AddSingleton(provider =>
{
    var options = provider.GetService<IOptions<DataverseOptions>>()!.Value;
    var httpClientFactory = provider.GetService<ProxyMsalHttpClientFactory>();
    var dataverseClientApplicationBuilder = ConfidentialClientApplicationBuilder
        .Create(options.ClientId)
        .WithClientSecret(options.ClientSecret)
        .WithAuthority(new Uri($"https://login.microsoftonline.com/{options.TenantId}/"));
    dataverseClientApplicationBuilder.WithHttpClientFactory(httpClientFactory);
    var dataverseClientApplication = dataverseClientApplicationBuilder.Build();
    dataverseClientApplication.AddInMemoryTokenCache();
    return dataverseClientApplication;
});


// Add services to the container.
builder.Services.AddScoped<IValidator<ImpactedIndividualVerificationRequest>, ImpactedIndividualVerificationValidator>();
builder.Services.AddScoped<IValidator<ImpactedIndividualLinkRequest>, ImpactedIndividualLinkValidator>();
builder.Services.AddScoped<IValidator<ContactUpdateMobileRequest>, ContactUpdateMobileValidator>();
builder.Services.AddScoped<IValidator<ContactUpdateEmailRequest>, ContactUpdateEmailValidator>();

builder.Services.AddAuthentication()
    .AddJwtBearer();
builder.Services.AddHttpClient("jwt")
    .ConfigurePrimaryHttpMessageHandler<ProxyHttpClientHandler>()
    .AddHttpMessageHandler<LoggingDelegatingHandler>();
    
builder.Services.ConfigureOptions<ConfigureJwtBearerOptions>();
builder.Services.AddAuthorization();
builder.Services.AddAuthorization(options =>
{
    options.DefaultPolicy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .RequireClaim("appid", builder.Configuration["AzureAd:AppId"])
        .Build();
});

builder.Services.AddControllers();

builder.Services.AddFluentValidationAutoValidation();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddFluentValidationRulesToSwagger();

var app = builder.Build();
app.UseExceptionHandler(exceptionHandlerApp =>
{
    exceptionHandlerApp.Run(async context =>
    {
        context.Response.StatusCode = StatusCodes.Status500InternalServerError;
        context.Response.ContentType = "application/json";


        await context.Response.WriteAsJsonAsync(new ErrorModel("Unexpected error, please try again later. If the problem continues, contact ASQA for assistance."));
    });
});
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseCors();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();