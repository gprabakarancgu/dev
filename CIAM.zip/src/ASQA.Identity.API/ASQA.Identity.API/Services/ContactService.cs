﻿using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using ASQA.Identity.API.Models;
using ASQA.Identity.API.Models.Identity.Contact;
using ASQA.Identity.API.Models.Identity.ImpactedIndividual;
using ASQA.Identity.Data;
using ASQA.Identity.Data.Model;
using Microsoft.Extensions.Options;

namespace ASQA.Identity.API.Services;

public class ContactService : IContactService
{
    protected IDataverseClient DataverseClient;
    private readonly ILogger<ContactService> logger;

    public ContactService(IDataverseClient dataverseClient,
        ILogger<ContactService> logger)
    {
        this.DataverseClient = dataverseClient;
        this.logger = logger;
    }

    public async Task<Response<Contact>?> UpdateEmail(ContactUpdateEmailRequest request)
    {
        var response = new Response<Contact>();

        var contact = await GetContact(request.ContactId);
        if (contact == null)
        {
            response.Error = new ErrorModel("There is no matching record for the ASQA Reference number and date of birth.");
            return response;
        }

        response = await UpdateEmail(request.ContactId, request.Email, contact);
        if (response?.Error != null)
        {
            return response;
        }

        return response;
    }

    public async Task<Response<Contact>?> UpdateMobile(ContactUpdateMobileRequest request)
    {
        var response = new Response<Contact?>();

        var contact = await GetContact(request.ContactId);

        if (contact == null)
        {
            response.Error = new ErrorModel("There is no matching record for the ASQA Reference number and date of birth.");
            return response!;
        }

        response = await UpdateMobile(contact.ContactId, request.Mobile, contact);
        if (response?.Error != null)
        {
            return response!;
        }

        return response!;
    }

    private async Task<IEnumerable<Contact>> GetContacts(string email)
    {
        var contacts = await DataverseClient.ListAsync(
            "contacts",
            new RequestOptions
            {
                Filter = $"emailaddress1 eq '{email}'",
                Select = string.Join(',', DataversConstats.ContactAttrNames)
            },
            convert: (e, _) => e.Deserialize<Contact>(new JsonSerializerOptions()
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                Converters = { new DataverseImpactedIndividualContactConverter() }
            }));
        return contacts!;
    }

    protected async Task<Contact?> GetContact(string contactId)
    {
        var contacts = await DataverseClient.ListAsync(
            "contacts",
            new RequestOptions
            {
                Filter = $"contactid eq '{contactId}'",
                Select = string.Join(',', DataversConstats.ContactAttrNames)
            },
            convert: (e, _) => e.Deserialize<Contact>(new JsonSerializerOptions()
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                Converters = { new DataverseImpactedIndividualContactConverter() }
            }));
        return contacts.FirstOrDefault();
    }

    protected async Task AssignRole(string contactId, string roleId)
    {
        var json = @$"{{
    ""@odata.id"": ""{DataverseClient.BaseAddress}mspp_webroles({roleId})""
}}";
        var response = await DataverseClient.PostAsync("contacts", json, "powerpagecomponent_mspp_webrole_contact/$ref", contactId, CancellationToken.None);
    }


    private async Task<Response<Contact>> UpdateEmail(string contactId, string email, Contact contact)
    {
        contact.SetEmail(email);

        var updateRequest = JsonNode.Parse(@$"{{
        ""{DataversConstats.EmailAttrName}"": ""{email}"",
        ""adx_identity_emailaddress1confirmed"": true
    }}");
        if (!string.IsNullOrEmpty(contact.Email2))
        {
            updateRequest![DataversConstats.Email2AttrName] = contact.Email2;
        }

        if (!string.IsNullOrEmpty(contact.Email2))
        {
            updateRequest![DataversConstats.Email3AttrName] = contact.Email3;
        }

        var updateEmailResponse = await DataverseClient.PatchAsync("contacts",
            updateRequest!.ToJsonString(), contactId);

        if (!updateEmailResponse.IsSuccessStatusCode)
        {
            logger.LogError(new Exception(
                    $"Status: {updateEmailResponse.StatusCode} Message: {await updateEmailResponse.Content.ReadAsStringAsync()}"),
                "Failed to update contact");
            return new Response<Contact> { Error = new ErrorModel("Unexpected error, please try again later. If the problem continues, contact ASQA for assistance.") };
        }

        return new Response<Contact> { Data = contact };
    }

    private async Task<Response<Contact?>> UpdateMobile(string contactId, string mobile, Contact contact)
    {
        contact.SetMobile(mobile);

        var updateRequest = JsonNode.Parse(@$"{{
        ""{DataversConstats.MobileAttrName}"": ""{mobile}"",
        ""adx_identity_mobilephoneconfirmed"": true
    }}");

        if (!string.IsNullOrEmpty(contact.Mobile2))
        {
            updateRequest![DataversConstats.Mobile2AttrName] = contact.Mobile2;
        }

        if (!string.IsNullOrEmpty(contact.Mobile3))
        {
            updateRequest![DataversConstats.Mobile3AttrName] = contact.Mobile3;
        }

        var updateEmailResponse = await DataverseClient.PatchAsync("contacts",
            updateRequest!.ToJsonString(), contactId);

        if (!updateEmailResponse.IsSuccessStatusCode)
        {
            logger.LogError(new Exception(
                    $"Status: {updateEmailResponse.StatusCode} Message: {await updateEmailResponse.Content.ReadAsStringAsync()}"),
                "Failed to update contact");
            return new Response<Contact?> { Error = new ErrorModel("Unexpected error, please try again later. If the problem continues, contact ASQA for assistance.") };
        }

        return new Response<Contact?> { Data = contact };
    }
}