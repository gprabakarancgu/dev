﻿using System.Text.Json;
using System.Text.Json.Serialization;
using ASQA.Identity.API.Models.Identity.Contact;

namespace ASQA.Identity.API.Services;

public static class JsonExtensions
{
    public static bool TryGetsString(this JsonElement je, out string? parsed)
    {
        var (p, r) = je.ValueKind switch
        {
            JsonValueKind.String => (je.GetString(), true),
            JsonValueKind.Null => (null, true),
            _ => (default, false)
        };
        parsed = p;
        return r;
    }
}

public static class DataversConstats
{
    public const string ContactIdAttrName = "contactid";
    public const string EmailAttrName = "emailaddress1";
    public const string Email2AttrName = "emailaddress2";
    public const string Email3AttrName = "emailaddress3";
    public const string MobileAttrName = "mobilephone";
    public const string Mobile2AttrName = "asqa_mobilephone2";
    public const string Mobile3AttrName = "asqa_mobilehpone3";
    public const string FirstNameAttrName = "firstname";
    public const string LastNameAttrName = "lastname";
    public const string FullNameAttrName = "fullname";
    public const string BirthDateAttrName = "birthdate";
    public const string ArnAttrName = "asqa_name";

    public static IEnumerable<string> ContactAttrNames = new[]
    {
        FirstNameAttrName, LastNameAttrName, FullNameAttrName, EmailAttrName, Email2AttrName, Email3AttrName,
        MobileAttrName, Mobile2AttrName, Mobile3AttrName, BirthDateAttrName
    };
}

public class DataverseImpactedIndividualContactConverter : JsonConverter<Contact>
{
    public override Contact? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType != JsonTokenType.StartObject)
        {
            throw new JsonException();
        }

        var contact = new Contact();

        while (reader.Read())
        {
            if (reader.TokenType == JsonTokenType.EndObject)
            {
                return contact;
            }

            // Get the key.
            if (reader.TokenType != JsonTokenType.PropertyName)
            {
                throw new JsonException();
            }

            string? propertyName = reader.GetString();
                
            // Get the value.
            reader.Read();
            switch (propertyName)
            {
                case DataversConstats.ContactIdAttrName:
                    contact.ContactId = reader.GetString();
                    break;
                case DataversConstats.EmailAttrName:
                    contact.Email = reader.GetString();
                    break;
                case DataversConstats.Email2AttrName:
                    contact.Email2 = reader.GetString();
                    break;
                case DataversConstats.Email3AttrName:
                    contact.Email3 = reader.GetString();
                    break;
                case DataversConstats.MobileAttrName:
                    contact.Mobile = reader.GetString();
                    break;
                case DataversConstats.Mobile2AttrName:
                    contact.Mobile2 = reader.GetString();
                    break;
                case DataversConstats.Mobile3AttrName:
                    contact.Mobile3 = reader.GetString();
                    break;
                case DataversConstats.FirstNameAttrName:
                    contact.FirstName = reader.GetString();
                    break;
                case DataversConstats.LastNameAttrName:
                    contact.LastName = reader.GetString();
                    break;
                case DataversConstats.FullNameAttrName:
                    contact.FullName = reader.GetString();
                    break;
                default:
                    break;
            }
        }

        throw new JsonException();
    }

    public override void Write(Utf8JsonWriter writer, Contact value, JsonSerializerOptions options)
    {
        throw new NotImplementedException();
    }
}