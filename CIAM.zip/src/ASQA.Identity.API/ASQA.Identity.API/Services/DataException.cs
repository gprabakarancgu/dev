﻿namespace ASQA.Identity.API.Services;

public class DataException : Exception
{
    public DataException(string message) : base(message)
    {
        
    }
}