﻿using ASQA.Identity.API.Models.Identity.Contact;
using ASQA.Identity.API.Models.Identity.ImpactedIndividual;

namespace ASQA.Identity.API.Services;

public interface IImpactedIndividualService
{
    Task<Response<Contact>> Verify(ImpactedIndividualVerificationRequest request);
    Task<Response<Contact>?> Link(ImpactedIndividualLinkRequest request);
}