﻿using ASQA.Identity.API.Models.Identity.Contact;
using ASQA.Identity.API.Models.Identity.ImpactedIndividual;

namespace ASQA.Identity.API.Services;

public interface IContactService
{
    Task<Response<Contact>?> UpdateEmail(ContactUpdateEmailRequest request);
    Task<Response<Contact>?> UpdateMobile(ContactUpdateMobileRequest request);
}