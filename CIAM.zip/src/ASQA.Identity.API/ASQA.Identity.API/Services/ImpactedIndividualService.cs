﻿using System.Text.Json;
using System.Text.Json.Nodes;
using ASQA.Identity.API.Models;
using ASQA.Identity.API.Models.Identity.Contact;
using ASQA.Identity.API.Models.Identity.ImpactedIndividual;
using ASQA.Identity.Data;
using ASQA.Identity.Data.Model;
using Microsoft.Extensions.Options;

namespace ASQA.Identity.API.Services
{
    public class ImpactedIndividualService : ContactService, IImpactedIndividualService
    {
        private readonly ILogger<ImpactedIndividualService> logger;
        private readonly DataverseOptions dataverseOptions;
        private readonly string b2cIssuer;

        public ImpactedIndividualService(IDataverseClient dataverseClient,
            ILogger<ImpactedIndividualService> logger,
            IOptions<B2COptions> b2cOptions,
            IOptions<DataverseOptions> dataverseOptions) : base(dataverseClient, logger)
        {
            this.logger = logger;
            this.dataverseOptions = dataverseOptions.Value;
            this.b2cIssuer = b2cOptions.Value.Issuer;
            if (string.IsNullOrEmpty(b2cIssuer))
            {
                throw new ArgumentNullException(nameof(b2cIssuer));
            }
        }

        public async Task<Response<Contact>> Verify(ImpactedIndividualVerificationRequest request)
        {
            var response = new Response<Contact>();

            var impactedIndividualInfo = await GetContactByArn(request.Arn);
            var impactedIndividualContact = impactedIndividualInfo?.Item1;
            if (impactedIndividualContact == null)
            {
                response.Error = new ErrorModel("There is no matching record for the ASQA Reference number and date of birth.");
                return response;
            }

            if (request.DateOfBirth != impactedIndividualInfo?.Item2)
            {
                if (impactedIndividualInfo?.Item2 == null)
                {
                    response.Error = new ErrorModel("There is no date of birth associated with this record. Please contact ASQA for assistance.");
                    return response;
                }
                response.Error = new ErrorModel("There is no matching record for the ASQA Reference number and date of birth.");
                return response;
            }

            if (request.CheckUserExists)
            {
                var externalIdentity = await GetExternalIdentityByContactId(impactedIndividualContact.ContactId);
                if (externalIdentity != null)
                {
                    response.Error =
                        new ErrorModel($"An account has already been created with this email. You can log in with the email address.");
                    return response;
                }
            }

            response.Data = impactedIndividualContact;

            return response;
        }

        public async Task<Response<Contact>?> Link(ImpactedIndividualLinkRequest request)
        {
            var response = new Response<Contact>();

            var externalIdentity = await GetExternalIdentityByContactId(request.ContactId);
            if (externalIdentity != null)
            {
                response.Error = new ErrorModel($"An account has already been created with this email. You can log in with the email address.");
                return response;
            }

            response = await CreateExternalIdentity(request.ContactId, request.ObjectId);
            if (response?.Error != null)
            {
                return response;
            }

            var impactedIndividualContact = await GetContact(request.ContactId);
            if (impactedIndividualContact == null)
            {
                response = new Response<Contact>
                {
                    Error = new ErrorModel("There is no matching record for the ASQA Reference number and date of birth.")
                };
                return response;
            }

            response = await UpdateContact(request.ContactId, request.ObjectId, request.Email, impactedIndividualContact);
            if (response?.Error != null)
            {
                return response;
            }

            await AssignRole(request.ContactId, dataverseOptions.ImpactedIndividualRoleId);

            return response;
        }

        private async Task<Response<Contact>> CreateExternalIdentity(string contactId, string objectId)
        {
            var createExternalIdBody = @$"{{
        ""adx_contactid@odata.bind"": ""/contacts({contactId})"",
        ""adx_identityprovidername"": ""{b2cIssuer}"",
        ""adx_username"": ""{objectId}"",
        ""adx_externalidentityid"": ""{Guid.NewGuid()}"",
        ""statuscode"": 1
    }}";
            var createExternalIdResponse = await DataverseClient.PostAsync("adx_externalidentities",
                createExternalIdBody, subEntitySetName: null, key: null, select: null, expand: "adx_contactid($select=contactid,emailaddress1,emailaddress2,emailaddress3)");
            var str = await createExternalIdResponse.Content.ReadAsStringAsync();
            if (!createExternalIdResponse.IsSuccessStatusCode)
            {
                logger.LogError(new Exception(
                        $"Status: {createExternalIdResponse.StatusCode} Message: {await createExternalIdResponse.Content.ReadAsStringAsync()}"),
                    "Failed to create external identity");
                return new Response<Contact> { Error = new ErrorModel("Unexpected error, please try again later. If the problem continues, contact ASQA for assistance.") };
            }

            return new Response<Contact>();
        }

        private async Task<Response<Contact>?> UpdateContact(string contactId, string objectId, string email, Contact impactedIndividualContact)
        {
            impactedIndividualContact.SetEmail(email);

            var updateRequest = JsonNode.Parse(@$"{{
        ""{DataversConstats.EmailAttrName}"": ""{email}"",
        ""adx_identity_emailaddress1confirmed"": true,
        ""adx_identity_username"": ""{objectId}"",
        ""adx_identity_logonenabled"": true,
        ""adx_identity_lockoutenabled"": true,
        ""adx_identity_securitystamp"": ""{Guid.NewGuid()}"",
        ""adx_profilemodifiedon"": ""{DateTime.UtcNow:yyyy-MM-dd'T'HH:mm:ss'Z'}""
    }}");
            if (!string.IsNullOrEmpty(impactedIndividualContact.Email2))
            {
                updateRequest![DataversConstats.Email2AttrName] = impactedIndividualContact.Email2;
            }

            if (!string.IsNullOrEmpty(impactedIndividualContact.Email2))
            {
                updateRequest![DataversConstats.Email3AttrName] = impactedIndividualContact.Email3;
            }

            var updateResponse = await DataverseClient.PatchAsync("contacts",
                updateRequest!.ToJsonString(), contactId);

            if (!updateResponse.IsSuccessStatusCode)
            {
                logger.LogError(new Exception(
                        $"Status: {updateResponse.StatusCode} Message: {await updateResponse.Content.ReadAsStringAsync()}"),
                    "Failed to update contact");
                return new Response<Contact> { Error = new ErrorModel("Unexpected error, please try again later. If the problem continues, contact ASQA for assistance.") };
            }

            return new Response<Contact> { Data = impactedIndividualContact };
        }

        private async Task<Tuple<Contact?, string?>?> GetContactByArn(string arn)
        {
            JsonArrayResponse<Tuple<Contact?, string?>> impactedIndividualContacts = await DataverseClient.ListAsync<Tuple<Contact?, string?>>(
                "asqa_qiarns",
                new RequestOptions
                {
                    Top = 1,
                    Expand = $"asqa_impactedindividual($select={string.Join(',', DataversConstats.ContactAttrNames)})",
                    Filter = $"asqa_name eq '{arn}'",
                    Select = "asqa_name"
                },
            convert: (e, _) =>
                {
                    if (!e.TryGetProperty("asqa_impactedindividual", out var impactedIndividual))
                    {
                        throw new ArgumentNullException("asqa_impactedindividual");
                    }

                    impactedIndividual.TryGetProperty(DataversConstats.BirthDateAttrName, out var birthDateElement);
                    birthDateElement.TryGetsString(out var dateOfBirth);

                    return new Tuple<Contact?, string?>(impactedIndividual.Deserialize<Contact>(new JsonSerializerOptions()
                    {
                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                        Converters = { new DataverseImpactedIndividualContactConverter() }
                    }), dateOfBirth);
                });
            return impactedIndividualContacts.FirstOrDefault();
        }

        private async Task<Contact?> GetExternalIdentityByContactId(string contactId)
        {
            var externalIdentities = await DataverseClient.ListAsync(
                "adx_externalidentities",
                new RequestOptions
                {
                    Top = 1,
                    Expand = "adx_contactid($select=contactid,emailaddress1)",
                    Filter = $"adx_contactid/contactid eq '{contactId}'",
                    Select = "adx_externalidentityid"
                },
                convert: (e, _) =>
                {
                    if (!e.TryGetProperty("adx_contactid", out var impactedIndividual))
                    {
                        return null;
                    }
                    ;
                    return impactedIndividual.Deserialize<Contact>(new JsonSerializerOptions()
                    {
                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                        Converters = { new DataverseImpactedIndividualContactConverter() }
                    });
                });
            return externalIdentities.FirstOrDefault();
        }

    }
}
