﻿using System.Net;

namespace ASQA.Identity.API;

public class ProxyHttpClientHandler : HttpClientHandler
{
    private readonly IConfiguration configuration;
    private readonly ILogger<ProxyHttpClientHandler> logger;

    public ProxyHttpClientHandler(IConfiguration configuration, ILogger<ProxyHttpClientHandler> logger)
    {
        this.configuration = configuration;
        this.logger = logger;
        Proxy = new WebProxy(new Uri(configuration["Proxy:BaseUrl"]!), true, null, new NetworkCredential(
            configuration["Proxy:Username"], configuration["Proxy:Password"],
            "nation"));
    }
}