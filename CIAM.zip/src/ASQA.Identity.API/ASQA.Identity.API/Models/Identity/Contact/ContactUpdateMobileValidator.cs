﻿using FluentValidation;

namespace ASQA.Identity.API.Models.Identity.Contact;

public class ContactUpdateMobileValidator : AbstractValidator<ContactUpdateMobileRequest>
{
    public ContactUpdateMobileValidator()
    {
        RuleFor(request => request.Mobile).NotEmpty().WithMessage("Mobile is required");
        RuleFor(request => request.ContactId).NotEmpty().WithMessage("Contact ID is required");
    }
}