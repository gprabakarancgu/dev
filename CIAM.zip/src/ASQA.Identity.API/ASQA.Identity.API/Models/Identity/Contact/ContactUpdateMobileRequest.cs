﻿namespace ASQA.Identity.API.Models.Identity.Contact;

public class ContactUpdateMobileRequest(string mobile, string contactId)
{
    public string ContactId { get; set; } = contactId;

    //public string? ObjectId { get; set; }
    public string Mobile { get; set; } = mobile;
}