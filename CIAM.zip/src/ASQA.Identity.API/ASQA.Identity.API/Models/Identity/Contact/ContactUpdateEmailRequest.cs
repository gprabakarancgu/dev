﻿namespace ASQA.Identity.API.Models.Identity.Contact;

public class ContactUpdateEmailRequest(string contactId, string email)
{
    public string ContactId { get; set; } = contactId;
    public string Email { get; set; } = email;
}