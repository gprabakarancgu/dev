﻿namespace ASQA.Identity.API.Models.Identity.ImpactedIndividual;

public class Response<TData>
{
    public TData Data{ get; set; }
    public ErrorModel Error { get; set; }

}