﻿namespace ASQA.Identity.API.Models.Identity.ImpactedIndividual
{
    public class ImpactedIndividualVerificationRequest(string dateOfBirth, string arn, bool checkUserExists = true)
    {
        public string DateOfBirth { get; set; } = dateOfBirth;
        public string Arn { get; set; } = arn;
        public bool CheckUserExists { get; } = checkUserExists;
    }
}
