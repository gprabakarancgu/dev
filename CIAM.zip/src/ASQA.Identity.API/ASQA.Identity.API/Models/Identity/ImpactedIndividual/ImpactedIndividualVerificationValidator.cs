﻿using FluentValidation;

namespace ASQA.Identity.API.Models.Identity.ImpactedIndividual
{
    public class ImpactedIndividualVerificationValidator : AbstractValidator<ImpactedIndividualVerificationRequest>
    {
        public ImpactedIndividualVerificationValidator()
        {
            RuleFor(request => request.DateOfBirth)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("Date of birth is required")
                .Matches(@"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$").WithMessage("Invalid date of birth");
            RuleFor(request => request.Arn).NotEmpty().WithMessage("ARN is required");
        }
    }
}
