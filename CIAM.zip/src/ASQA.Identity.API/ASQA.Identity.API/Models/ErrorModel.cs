﻿namespace ASQA.Identity.API.Models
{
    public class ErrorModel
    {
        public ErrorModel(string userMessage)
        {
            UserMessage = userMessage; 
        }
        public string Version => "1.0.0";
        public int Status => 400;
        public string UserMessage { get; set; }
    }
}
