param ( 
    [Parameter(Mandatory = $true)]
    [string]$env,

    [string]$settings = "",

    [string]$policiesFolder = "b2c-policies"
)

Write-Host $PWD

# Define paths
$jsonFilePath = "$policiesFolder\environments\$env\$env.json"
$outputFolder = "$policiesFolder\environments\$env\policies"

# Validate JSON file exists
if (-not (Test-Path $jsonFilePath)) {
    Write-Error "JSON config file '$jsonFilePath' not found."
    exit 1
}

# Load key-value pairs from the JSON file
$keyValues = Get-Content $jsonFilePath | ConvertFrom-Json

$items = $settings -split ","
foreach ($item in $items) {
    $value =  [System.Environment]::GetEnvironmentVariable($item)
    if (Get-Member -inputobject $keyValues -name $item -Membertype Properties) {
        $keyValues.PSObject.Properties.Remove($item)
        Write-Host "Property '$item' removed."
    }
    $keyValues | add-member -Name $item -value $value -MemberType NoteProperty
}

Write-Host (ConvertTo-Json $keyValues)

# Create output folder if it doesn't exist
if (-not (Test-Path $outputFolder)) {
    New-Item -ItemType Directory -Path $outputFolder | Out-Null
}

# Process each XML file in the current directory
Get-ChildItem -Path $policiesFolder -Filter *.xml | ForEach-Object {
    $file = $_
    $content = Get-Content $file.FullName -Raw

    # Replace all placeholders
    foreach ($key in $keyValues.PSObject.Properties.Name) {
        $pattern = "\{config:$key\}"
        $replacement = $keyValues.$key
        $content = [regex]::Replace($content, $pattern, $replacement)
    }

    # Write updated content to env-specific folder
    $outputPath = Join-Path $outputFolder $file.Name
    Set-Content -Path $outputPath -Value $content -Encoding UTF8
}

$keyValues = Get-Content $jsonFilePath | ConvertFrom-Json
$partitioned =  ($keyValues.PSObject.Properties | Where-Object { $_.Name -eq 'Partitioned' }).Value

if ($null -ne $partitioned -and $partitioned.ToLower() -eq "true") {
    Write-Host "Partitioned: $partitioned"
    $envName = $env.ToUpper()
    $files = get-childitem -path $outputFolder -name -include *.xml | Where-Object { ! $_.PSIsContainer }
    foreach ( $file in $files ) {
        $PolicyFile = (Join-Path -Path $outputFolder -ChildPath $file)
        $PolicyData = Get-Content $PolicyFile
        [xml]$xml = $PolicyData
        
        $parts = $xml.TrustFrameworkPolicy.PolicyId -split "B2C_1A_"
        $xml.TrustFrameworkPolicy.PolicyId = "B2C_1A_${envName}_$($parts[1])"

        # Update BasePolicy PolicyId element
        $parts = $xml.TrustFrameworkPolicy.PublicPolicyUri -split "B2C_1A_"
        $xml.TrustFrameworkPolicy.PublicPolicyUri = "$($parts[0])B2C_1A_${envName}_$($parts[1])"

        if ($null -ne $xml.TrustFrameworkPolicy.BasePolicy) {
            $parts = $xml.TrustFrameworkPolicy.BasePolicy.PolicyId -split "B2C_1A_"
            $xml.TrustFrameworkPolicy.BasePolicy.PolicyId = "B2C_1A_${envName}_$($parts[1])"
        }
        $xml.Save($PolicyFile)
    }
}


Write-Host "Processed XML files saved in '$outputFolder' using '$jsonFilePath'."



# SIG # Begin signature block
# MIIPcAYJKoZIhvcNAQcCoIIPYTCCD10CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQULi2TJgQGoE/7P0ZefgPaw/uU
# lQCgggzEMIIGOjCCBSKgAwIBAgITQwAAAAIGvAm/42kSbAAAAAAAAjANBgkqhkiG
# 9w0BAQsFADAlMSMwIQYDVQQDExpBdXN0cmFsaWFuIEdvdmVybm1lbnQgUm9vdDAe
# Fw0yMzA3MTIwODUzMzZaFw0zMzA3MTIwOTAzMzZaMF4xFDASBgoJkiaJk/IsZAEZ
# FgRlbmV0MRswGQYKCZImiZPyLGQBGRYLYXBwbGljYXRpb24xKTAnBgNVBAMTIEF1
# c3RyYWxpYW4gR292ZXJubWVudCBQcm9kdWN0aW9uMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAomBgucfMN/T+RN/nF7nBYVJBWJRFnLshf1/IStob/p/n
# 6WoLmP+6BIUmU6oMl9XyIqsZsBKruBpnxUdsBeGzYTsl5nAFG6UE35cYEiqZh5v/
# n6OW8ZEeVustIyWaWL1xCtZEVHLq4RqP0I6eqOewhhvi/UhTqrAvPKlbRBl0eNWP
# PmFzuSWkN/5J3Gbv4u9WLrkmBQSqGpEGxM6IGOQU3jAxVvAPXIgSFX7npWmo5aTo
# HBEM96YZsAPQIkbFmDJcjjdjrAGS/LRmnmgIxQqqhlxA/csZzyIp7yOZYBYZ/BFm
# V39lvWHvdp8Rl8ZgVcGyMNIO8j7KG6Mt6weH1aIitQIDAQABo4IDKDCCAyQwEAYJ
# KwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFOtHP6kdjFcY7sjL3q9dGSJtMjJ6MBkG
# CSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8E
# BTADAQH/MB8GA1UdIwQYMBaAFCZEV2b+sP4JDEjk6k6F30PWRTx2MIIBTAYDVR0f
# BIIBQzCCAT8wggE7oIIBN6CCATOGgdFsZGFwOi8vL0NOPUF1c3RyYWxpYW4lMjBH
# b3Zlcm5tZW50JTIwUm9vdCxDTj1BdXN0R292Um9vdCxDTj1DRFAsQ049UHVibGlj
# JTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbiwl
# MjBEQz1hcHBsaWNhdGlvbixEQz1lbmV0P2NlcnRpZmljYXRlUmV2b2NhdGlvbkxp
# c3Q/YmFzZT9vYmplY3RDbGFzcz1jUkxEaXN0cmlidXRpb25Qb2ludIZdaHR0cDov
# L0VEQ19Qcm9kdWN0aW9uX0NBLmhvc3RzLmFwcGxpY2F0aW9uLmVuZXQvQ2VydEVu
# cm9sbC9BdXN0cmFsaWFuJTIwR292ZXJubWVudCUyMFJvb3QuY3JsMIIBRQYIKwYB
# BQUHAQEEggE3MIIBMzCBxQYIKwYBBQUHMAKGgbhsZGFwOi8vL0NOPUF1c3RyYWxp
# YW4lMjBHb3Zlcm5tZW50JTIwUm9vdCxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIw
# U2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbiwlMjBEQz1hcHBs
# aWNhdGlvbixEQz1lbmV0P2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1j
# ZXJ0aWZpY2F0aW9uQXV0aG9yaXR5MGkGCCsGAQUFBzAChl1odHRwOi8vRURDX1By
# b2R1Y3Rpb25fQ0EuaG9zdHMuYXBwbGljYXRpb24uZW5ldC9DZXJ0RW5yb2xsL0F1
# c3RyYWxpYW4lMjBHb3Zlcm5tZW50JTIwUm9vdC5jcnQwDQYJKoZIhvcNAQELBQAD
# ggEBAI06Xi/l2fByQnLQokm2WVI9a/1Lgd/s1+SfZSld6NiyoifYmba75GRt7HSG
# kxC+QvbhUrj9nWZJkrUzNCSNJ9tJG49OP0JvLk9DJoKCeL8oCvIybduut1+JITWg
# ItHx+d/N+/xo1Mkv6Dvhn6A3lwAPzXSeJZ5jTnzwLdza5rDNV0XTdJtxpBsRF+B+
# lZQIsH+Ym3HbngaY+xe9DQ2B2aWhU1IM2jeqyx2tvw5EM7lg68LY1G3OCgTkBc1V
# 3dOVYgQTtqoGTO9hlElxlhwCAht3z3eECy4UppEksOORAel7hDibbMHeZTikZyMY
# 1SGapcF6WX6va2Sc3YqkYTttUBMwggaCMIIFaqADAgECAhNwAAAAC//S3VJi1WrZ
# AAAAAAALMA0GCSqGSIb3DQEBCwUAMF4xFDASBgoJkiaJk/IsZAEZFgRlbmV0MRsw
# GQYKCZImiZPyLGQBGRYLYXBwbGljYXRpb24xKTAnBgNVBAMTIEF1c3RyYWxpYW4g
# R292ZXJubWVudCBQcm9kdWN0aW9uMB4XDTIzMDgzMTIyNDY0OFoXDTI4MDgyOTIy
# NDY0OFowJzElMCMGA1UEAxMcREVXUiBDb2RlIFNpZ25pbmcgUHJvZHVjdGlvbjCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKKeht0lg0CeBtMASalbHHAZ
# 2h7JMKjDe/BCbJqPTFVRC0Yg1Ws1m92CcNyOwbvtLMNVyFasyUd4RPxOYfZCZyMe
# TdlXpDKPBv7+2ZZinqyjjoaIJJn7ZegNq+PmdUOXxwb/OxedG5cyYoI4kaEhqrpE
# p1F7NVTF+fmfcfiDvSW1vIS8kgC2aH8MH0hbETdY0YyQikclJoKtAd0P11a+gYfT
# Mkc+EjMhKfyBhFYHmEcnaazemEIWVRAqjfdpoZIs1Mu694OZpXo/yY3a+cRUlho0
# LOYb3VIXxadQjW6+y0ZQvoH6WQ/cPxWKW9ZovJyt781yj1irHfEQWA4CkZ8vvQEC
# AwEAAaOCA24wggNqMDwGCSsGAQQBgjcVBwQvMC0GJSsGAQQBgjcVCPL9eIaKrxKG
# vYM3hc/tY4S6rywRgsqNcIbExwcCAWQCAQYwEwYDVR0lBAwwCgYIKwYBBQUHAwMw
# DgYDVR0PAQH/BAQDAgeAMBsGCSsGAQQBgjcVCgQOMAwwCgYIKwYBBQUHAwMwHQYD
# VR0OBBYEFK+ZLLkrr3fr5g1YfAaapzoSBBF9MB8GA1UdIwQYMBaAFOtHP6kdjFcY
# 7sjL3q9dGSJtMjJ6MIIBVAYDVR0fBIIBSzCCAUcwggFDoIIBP6CCATuGgdNsZGFw
# Oi8vL0NOPUF1c3RyYWxpYW4lMjBHb3Zlcm5tZW50JTIwUHJvZHVjdGlvbixDTj1F
# UFJJU0VDMjA1LENOPUNEUCxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1T
# ZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPWFwcGxpY2F0aW9uLERDPWVuZXQ/
# Y2VydGlmaWNhdGVSZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdENsYXNzPWNSTERp
# c3RyaWJ1dGlvblBvaW50hmNodHRwOi8vRURDX1Byb2R1Y3Rpb25fQ0EuaG9zdHMu
# YXBwbGljYXRpb24uZW5ldC9DZXJ0RW5yb2xsL0F1c3RyYWxpYW4lMjBHb3Zlcm5t
# ZW50JTIwUHJvZHVjdGlvbi5jcmwwggFOBggrBgEFBQcBAQSCAUAwggE8MIHIBggr
# BgEFBQcwAoaBu2xkYXA6Ly8vQ049QXVzdHJhbGlhbiUyMEdvdmVybm1lbnQlMjBQ
# cm9kdWN0aW9uLENOPUFJQSxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1T
# ZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPWFwcGxpY2F0aW9uLERDPWVuZXQ/
# Y0FDZXJ0aWZpY2F0ZT9iYXNlP29iamVjdENsYXNzPWNlcnRpZmljYXRpb25BdXRo
# b3JpdHkwbwYIKwYBBQUHMAKGY2h0dHA6Ly9FRENfUHJvZHVjdGlvbl9DQS5ob3N0
# cy5hcHBsaWNhdGlvbi5lbmV0L0NlcnRFbnJvbGwvQXVzdHJhbGlhbiUyMEdvdmVy
# bm1lbnQlMjBQcm9kdWN0aW9uLmNydDANBgkqhkiG9w0BAQsFAAOCAQEAho9YA8dL
# RRSy2qcE9SuOcUGwlvphIVb4j1P8amNQa6WvJUA1+sLoFTAc/rNaCSu57N9ky5NA
# ghBDF9YE1508DJsAv2jsBWef/HySsY6BYW/nlIv2ZYMNNZJc78QOld9+jQr3Pt6W
# rH1zlKtpvMNvytjlT5P5LnybiCXmWYRaG4UZIYWC9U6Cl3kaeh14/nGAhd+IP+O9
# +0O4p9HuBkDNY6CFeDACXwAjB2pY0MTLd3dg1YQ8JQGpJTgmuge7TA45lY16YY7c
# 9wn7WaXk7VcemLRWkfgW4vJRwUU66oSCP0ofvr8Br2xqklzj4BBjLUhDdXyqOz/6
# mwryjFZ5tRaMTTGCAhYwggISAgEBMHUwXjEUMBIGCgmSJomT8ixkARkWBGVuZXQx
# GzAZBgoJkiaJk/IsZAEZFgthcHBsaWNhdGlvbjEpMCcGA1UEAxMgQXVzdHJhbGlh
# biBHb3Zlcm5tZW50IFByb2R1Y3Rpb24CE3AAAAAL/9LdUmLVatkAAAAAAAswCQYF
# Kw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkD
# MQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJ
# KoZIhvcNAQkEMRYEFBTny+S1r/GdOcnlwB0jrX2QiLPSMA0GCSqGSIb3DQEBAQUA
# BIIBAC8iYVpMecWOwbCRx4B6uXIiPVZAvlM8Y5ggYzuOdOTsSsiiOyF+KMM4bycj
# MD+31JgPrDWSngp+bATijFszNAGi7P4nW04OCnwZVki6j5eH4JB8zFqFrAav/kX+
# gyJnv1oHIH9VhQ8KJ2oBPLZ6BwpdO2S0Hs5CPGAz9s5rqGlwC1UNCykQpxUG2FBd
# zdLTom+JWHKyTmaRam1iXcodgy0S4uYh+Ej2K4DdUY8AZoYv4jRcU15UkKWrQbL+
# WifZ50rIdJNqJVJzeKKF8pZYahpPlLv+j/T+cfF5FZCwuFtDTVV0WOjVwWFao44v
# 7G1+MTxghe4ZQYlXMK+r1IVLtN4=
# SIG # End signature block
